################
# Assignment 1 #
################

#------------------------------------------------------------------------------#
# MONTE CARLO SIMULATIONS 
# a.k.a. exploiting the potential of R while learning how the stats we do works

# Simulate ORDINARY LEAST SQUARES
# OLS Regression assumes that our dependent variable (Y) is a linear function 
# of a set of independent variables (X's) plus a stochastic (random) component
# that we will call "epsilon".
# The parameters that describe the relationship between Y and each X are generally
# called "betas". They define the linear relation between all the X's and "mu",
# the systematic component of our model.
# For each observation, "epsilon" is the difference between "mu", i.e. the value 
# of Y predicted by our model (i.e. beta0 + beta1*x1 + beta2*x2 and so on), and 
# the real value of Y for that observation.
# In OLS we make some assumptions about the stochastic component of the model,
# i.e. about how "epsilon" should be distributed.
# More specifically, "epsilon" is supposed to follow a normal distribution
# with mean = 0 and a constant variance (check for "OLS assumptions" on Google
# to know more on this, although you should have already learned this part in 
# the Quantitative Methods class).
#
# What has been outlined here is a type of Data Generating Process (DGP), i.e. 
# a description of how the values of the variable of interest are generated in
# the population.
# The general aim of a statistical analysis is to infer the DGP by analyzing
# observable data sampled from the population. We don't know the "true" DGP,
# and this is why we need to estimate it. Here the situation is different though.
#
# A Monte Carlo simulation is simply an exercise in which we know the DGP.
# To cite a professor I met, "we ourselves are divinely knowledgeable in the 
# MC world: unlike ordinary mortals we really know the population characteristics 
# for a fact and can take as many random samples from the population as we wish".
#
#-------------------------------------------#
# Monte Carlo simulation of a bivariate OLS #
#-------------------------------------------#

# Method 1 - Repeat the DGP for each sample

ex1.beta.0 <- NULL 	# create an empty vector for the estimated intercepts
ex1.beta.1 <- NULL 	# create an empty vector for the estimated slopes
a <- 0.2 						# set the true value of the intercept
b <- 0.5 						# set the true value of the slope
n <- 1000 					# set the number of observations
X <- rnorm(n, 0, 1)	# generate X. Here X is defined outside of the loop because
											# one of the assumptions in the OLS is that X should be
											# fixed across repeated samples. However, this assumption
											# is hardly met, especially with social science data
											# (in an experimental setting it's another story, but the
											# most of us use observational data). 
											# The light version of this assumption is that X's are not
											# correlated with the residual error from the estimated
											# model, i.e. our sample is not self-selected on the
											# basis of X
sims <- 1000				# set the number of simulations
# Let's simulate!
for (i in 1:sims) {								# run 1000 simulations using a "for" loop
	Y <- a + b*X + rnorm(n, 0, 1) 	# generate Y as a function of X, the model
	   															# parameters and a normally-distributed error
																	# with mean=0 and sd=1
	model <- lm(Y ~ X) 							# estimate the OLS model
	ex1.beta.0[i] <- model$coef[1] 	# store the estimated intercept
	ex1.beta.1[i] <- model$coef[2] 	# store the estimated slope
}

# Let's have a look at how our population parameters are distributed
hist(ex1.beta.0, col = "blue") 		
hist(ex1.beta.1, col = "blue") 		


# Method 2 - Use the DGP to create the population, and then sample from it
#
# Here, what we do is more similar to the common sampling strategy used to collect
# social science data (in theory). We first create a population where relations
# between variables are set by the DGP that we decide, and then we repeatedly
# sample from it.

ex2.beta.0 <- NULL 	# create an empty vector for the estimated intercepts
ex2.beta.1 <- NULL  # create an empty vector for the estimated slopes
a <- 0.2 						# set the true value of the intercept
b <- 0.5 						# set the true value of the slope
n <- 100000 				# define the size of the population
X <- rnorm(n, 0, 1)  					# Generate X
Y <- a + b*X + rnorm(n, 0, 1) 	# Generate Y (same as above)
data <- data.frame(cbind(Y,X))  # Put Y and X in a data frame, for convenience
true.model <- lm(data$Y ~ data$X)  # Run the population model
true.beta.0 <- true.model$coef[1]  # Store the "true" intercept
true.beta.1 <- true.model$coef[2]  # Store the "true" slope
samplesize <- 1000	# set the sample size
sims <- 1000 				# set the number of simulations
# Let's simulate!
for (i in 1:sims) {
	samp <- sample(n, size = samplesize, replace = F) # generate a random sample
																										# of observations
	newdata <- data[samp,] 							# collect our data given our sample
	model <- lm(newdata$Y ~ newdata$X) 	# run the OLS model with our sample
	ex2.beta.0[i] <- model$coef[1] 			# store the estimated intercept
	ex2.beta.1[i] <- model$coef[2] 			# store the estimated slope
}
# Let's have a look at how our population parameters are distributed
hist(ex2.beta.0, col = "blue")
hist(ex2.beta.1, col = "blue")

# Let's compare the parameters estimated from our samples with the "true"
# parameters of the population
print(true.beta.0)
mean(ex2.beta.0)

print(true.beta.1)
mean(ex2.beta.1)

#------------#
# Exercise 1 #
#------------#
# Let's go back to method 1, and see what happens when we have two independent
# variables and they are correlated by different levels.

# To do this, we first need to create multivariate normal distributions
require(MASS)				# Load a package that allows to do so
ex3.beta.0 <- NULL 	
ex3.beta.1 <- NULL 	
ex3.beta.2 <- NULL
a <- 0				# set the true intercept at 0
b1 <- 0.5     # set the true slope for b1 at 0.5
b2 <- 0.5     # set the true slope for b2 at 0.5
n <- 1000
vcov <- matrix(c(1,0.5,0.5,1), nrow = 2, ncol = 2)
# the vcov is the variance-covariance matrix used to determine the variation
# of our two simulated variables and their level of correlation
# Here we set the variance for each of them at 1, and their correlation
# at 0.5
ind.var <- data.frame(mvrnorm(n = n, mu = c(0,0), Sigma = vcov))
# Since this time we have two variables, better to put them into a data frame
# we can check if the two variables are correlated to the extent that we want
# using the cor() function
cor(ind.var$X1,ind.var$X2)
names(ind.var) <- c("X1","X2")  # rename the variable in the data frame 
sims <- 1000										# set the number of simulations
for (i in 1:sims) {
	Y <- a + b1*ind.var$X1 + b2*ind.var$X2 + rnorm(n, 0, 1) 
	# ^ generate Y as done above
	model <- lm(Y ~ ind.var$X1 + ind.var$X2) 	# estimate multivariate OLS
	ex3.beta.0[i] <- model$coef[1] 	# store the estimated intercept
	ex3.beta.1[i] <- model$coef[2] 	# store the estimated slope for X1
	ex3.beta.2[i] <- model$coef[3] 	# store the estimated slope for X2
}
hist(ex3.beta.0, col = "blue",freq=F) 		
hist(ex3.beta.1, col = "blue",freq=F) 		
hist(ex3.beta.2, col = "blue",freq=F)
sd(ex3.beta.0)
sd(ex3.beta.1)
sd(ex3.beta.2)
# Change the level of correlation between X1 and X2 by changing the values
# in the variance-covariance matrix
# How do the distributions of the coefficients change from when the correlation 
# is very low (e.g. 0 or 0.1) to when it's very high (e.g. 0.9)?
# Use lattice graphics to plot the several distributions of coefficients 
# on different panels and on the same panels. That will give you a better sense
# of the differences.
# The plots should be as much self-explanatory as possible (i.e. legends for
# colors or types of line, labels, titles, etc.)


#------------#
# Exercise 2 #
#------------#
# Based on Method 2, re-run the experiment changing some settings.
# What happens to the estimated parameters when you have a very small sample
# size? How do they change in respect to the "true" population parameters?


# For both exercises, I want a script file with the syntax that you used to
# get to your conclusions. 
# Write your reflections and conclusions as comments on the script.
# For the plots I want both the syntax and the exported picture 
# (possibly in .png format).
