##################################
# Day 1 - Moving the first steps #
##################################

# Before starting:
# 1. As you may have noticed, the dash ("#") sign allows to to comment your code
# 	 without executing it. It will be still displayed in the console, but it will
#		 be ignored by R.
# 2. While with the R GUI you need to type Ctrl + R to send your command from the 
# 	 script to the console (Strg + R in German keyboards), in R-Studio you will
#		 have to type Ctrl + Enter (Strg + Enter in German)
# 3. When your code is longer than 1 line (it will happen frequentyl) you will need 
# 	 to select it all if you want R to run it. However, unlike Stata, this is not
# 	 always mandatory. If you want to run a single line of syntax, you can just put 
# 	 the cursor on it and type Ctrl + Enter. The positive thing is that you can 
# 	 highlight/select only a part of your syntax, and R will execute only that part.
# 	 We will see how it works later.
# 4. For SPSS users: you won't need to put a period at the end of your command.

#######################
# Getting help with R #
#######################
# This part is very important. You will use the help facilities a lot, at any level
# of expertise.
help.start()		# General help for R. It containt many pieces of material, including
# a general intro to R.
demo()					# A number of demos for the packages in the base version
# Example
demo(graphics)	# This shows you R's potential for graphics
# More commonly, you will need to know how some particular functions work

# Let's say you want to calculate the mean of a series of numbers. You know
# that R provides a function "mean()", but you don't know how to specify it
help(mean)
# or
?mean 					# That's the shortest way to ask help
# Sometimes you won't find a direct link to the help page for a certain function.
# In this case, you can call the help.search()
help.search("mean")
# or
??mean 					# This will return a list of help files containing the word "mean"

# Finally
example(mean) 	# Will provide you with examples about how to use a function

###########################
# Basic Operations with R #
###########################
6 + 6 + 6

6 + 6 * 6

(6 + 6) * 6

6^4 				# Raises 6 to the power of 4
sqrt(9)			# Squared root of 9
abs(-7) 		# Returns the absolute value of a number

# Note the "[1]" next to the output in the console. In R, every number you write
# or send to the console is interpreted as a vector. The "[1]" below indicates 
# that the index of the first item displayed is "1", i.e. it is the first number
# in the vector.

# We can also work with entire vectors in the form of series of numbers...
c(0,1,1,2,3,5,8,13,21,34)  # The "c" means "combine"

# ...or sequences
1:100			  # notice here the number at the beginning of each line of the output
# This is the same as writing:
c(1:100)


# Some examples to see the R logic
c(1,2,3,4) * c(100,200,300,400) # here you're performing an operation on two vectors

c(1,2,3,4) * c(100,100,100,100) # here too, but you'll get the same result as the 
# following (shorter) command
c(1,2,3,4) * 100  # multiply a vector and a scalar

c(1,2,3,4) * c(100,200) # when one vector is multiple of the other
c(1,2,3,4,5,6) * c(100,200,300)

c(1,2,3,4) * c(100,200,300)
# meet the "Warning message"

# When you get a Warning message:
# R is telling you that he's doing what you required, but things are not going
# smoothly as you planned.
#
# In out case, the length of one vector is not a multiple of the length of the 
# other. Therefore R did what you asked for, but for the last number it had to
# improvise (it has chosen arbitrarily that the remainder number is multiplied 
# by the first of the vector, but it could have been the last and it would have 
# made equally sense).


# Different thing is the "Error message". That tells you that R does not know 
# what to do with the command you gave. 9 out of 10 times it's due to some typos
# in the syntax. However, it can also be due to wrong commands, specifications,
# problems with the type of data, etc.

c(1,2,3,a)  # "a" is not a number, so R is assuming it's an object.

###########
# Objects #
###########
# What is an object?
# In abstract terms, objects are items that contain a certain amount of information.
# Being R an object-oriented language, you can do (and in fact you do) everything 
# with objects. 
# You can think of an object as a variable, to which you can assign values.
x <- 7
x
# Notice that something appeared in the top-right panel. This is one of the cool
# points of RStudio
# You can see what is inside an object in two ways:
x 				# either you just 'call' it
print(x)	# or you apply the "print" function

# Objects can be given arbitrary names
Beatles <- c("John", "Paul", "George", "Ringo")
print(Beatles)
`Sgt. Peppers Lonely Heart's Club Band` <- Beatles
`Sgt. Peppers Lonely Heart's Club Band`
# or
print(`Sgt. Peppers Lonely Heart's Club Band`)
# If the name contains special characters (or spaces), then it should be enclosed 
# by backticks "`".
# Also notice that objects do not necessarily have to contain numbers
# However, to specify that the item that you add to the object must be intended 
# as a character (and not as a number) you will need to use quotation marks ""
# So:
object <- word			# Leads to error
object <- "word"		# This works
object
# This all works also the other way round
10 -> ten
ten

# Notice that the symbol "=" has the same function as "<-"
one <- 1
two <- 2
one = two
one
two
# We just assigned the content of "one" to "two". That is different from
one == two 
# The "==" means "Is the value of "one" the same as the value of "two"?

# Other relational operators can be used to compare objects
one < two
one <= two
ten > two
ten != two

# How to see the objects in memory
# (This is not a big issue with RStudio, since they are shown in the up-right panel)
ls() 					# This shows you what is stored in R's memory
objects()			# Also this will work

# Objects can also be deleted, if you don't need them
rm(one)
one
# This may seem useless right now, but it turns very important when you have very
# large objects (e.g. full datasets) in memory, and R slows down
# You can also remove all the objects in memory
rm(list=ls()) 		


###########################
# Operations with objects #
###########################
y <- 1:365
x <- 7
y/x
# Which is the same as writing
1:365/7 # but it's shorter

# Objects can be combined together into other objects
z <- 6
a <- c(x,y,z)

# You can select any element in any vector
a[1]
a[367]
# The "print" function still works here
print(a[200])
a[200]
# You can select groups of elements
a[1:4] 	# Think about how this can be related to select variables in datasets

# Elements in a vector can be given names
vec <- 1:3
vec
names(vec) <- c("a","b","c")
vec
vec["a"]   	# Names must be specified with quotation marks

# You can select elements according to some selection rules
a[a>200]
a[a>200 & a<202] 			
a[a==50 | a > 300]
a[a > 360 & a != 365]
# Notice the difference between
a[250]
# and
a[a==250]
# The first example selects the 250th item in "a", which does not correspond to 
# the number "250"

# The items you select do not need to be consequential
a[c(1:4,69,366,367)]  # Why did I apply the "c()" function here?
a[1:4,69,366,367]
# When you select items in an object, the comma "," means that you are changing 
# dimension. Our vector "a" has only 1 dimension, so R is telling you that you
# requested to see items from dimensions that are not in the object.

# A 2-dimensional object
b <- matrix(data = 1:25, nrow = 5, ncol = 5) 

b # Notice the commas next to the rwo and column indexes
# Also, notice that the numbers are ordered by colums, rather than by rows
# This is called "column-major order"
# You can fill the matrix by row adding the option "byrow"
b.row <- matrix(data = 1:25, nrow = 5, ncol = 5, byrow = T)
b.row

b[1,4] # The first number refers to the row number, the second to the column number
# You can substitute elements selecting them in the same way
b[1,4] <- 1000
b
# You can select columns and perform operations with them
b[,1] + b[,3]		# Think about this as the sum of two variables in a dataset
# You can select items in an arbitrary order
b[,c(1,5,2)] # and they will be returned in the order you asked for
b[c(4,2),] # another example, with rows
# Notice that the output does not report the "original" row and column numbers,
# but the numbers that the selected rows and columns have in the new defined object.
# In other words, the two unordered rows of "b"
b[c(4,2),] # can be put into another object. Let us call it "e"
e <- b[c(4,2),]
# Now the 1st row in "e" is the 4th rwo in "b"
e[1,]
b[4,]

# We can ask R to tell which elements are the same in the two objects
e[1,] == b[4,] 
# It return an answer for each item in the two vectors

# The same rules for operations apply here
b + 1
b * x
c <- -2:2
b * c # Notice that vectors are multiplied by columns, rather than rows
# This command gives a simple multiplication of the single number in the matrix 
# with the single numbers in the vector. If you want to perform a matrix multiplication
# then you will need some different symbols
b %*% c 	# This gives you the result of the matrix multiplication of b by c
# Which is equivalent, for every line, to do:
b[1,1]*c[1] + b[1,2]*c[2] + b[1,3]*c[3] + b[1,4]*c[4] + b[1,5]*c[5]
b[2,1]*c[1] + b[2,2]*c[2] + b[2,3]*c[3] + b[2,4]*c[4] + b[2,5]*c[5]
b[3,1]*c[1] + b[3,2]*c[2] + b[3,3]*c[3] + b[3,4]*c[4] + b[3,5]*c[5]
b[4,1]*c[1] + b[4,2]*c[2] + b[4,3]*c[3] + b[4,4]*c[4] + b[4,5]*c[5]
b[5,1]*c[1] + b[5,2]*c[2] + b[5,3]*c[3] + b[5,4]*c[4] + b[5,5]*c[5]
d <- c(1,2,3,4)
# you can add rows and columns to a matrix through the "rbind" and cbind" functions
cbind(b,c)
rbind(b,c)
b <- cbind(b,c)
b

# Again, you can give names to rows and columns in matrices, and call elements with this
rownames(b) <- c("r1","r2","r3","r4","r5")
colnames(b) <- c("c1","c2","c3","c4","c5","c6")

b
b[,"c6"]
b["r3",]
b["r2","c3"]

############
# Exercise #
############
# Create a matrix called "max" with 10 rows and 10 columns with the numbers from 1 to 100
# Create a vector called "vex" containing the numbers from 1 to 10
# add "vex" as a row at the bottom of "max"
# Tell R to show you "max" when "max" is equal to 67
# Which numbers are in column 3?
# Which number occupies the position in row 8, column 4? Substitute it with 5500
# Delete the last row of "max" (the one added with "vex")








# Solution
max <- matrix(data = 1:100, nrow = 10, ncol = 10)
vex <- c(1:10)
s <- rbind(max,vex)
max[max==67]
max[,3]
max[8,4]
max[8,4] <- 5500
max <- max[1:10,]
max

##########################
# Other types of objects #
##########################
# So far we have seen objects like scalars (single numbers), vectors (or, more
# precisely "atomic vectors", i.e. sequences of elements of the same type)
# and matrices (two-dimensional sets of elements of the same type)
# Other types of objects that R can manage are Arrays, Lists and Data Frames

# Arrays are like vectors or matrices, but they can have more than 2 dimensions
# When you define an array, you will need to add an additional attribute for the
# dimensionality
arr <- array(1:27, dim = c(3,3,3))
arr
# You can select elements in the same way as we have seen for the matrices
arr[1,1,1]
arr[1,3,1]
arr[1,1,3]
arr[,,1] 			# A "slice", i.e. a matrix which is the subset of our array
arr[1,,] 			# A matrix made by the first row of each submatrix
arr[,1,] 			# A matrix made by the first column of each submatrix
# You can also construct arrays indirectly
arr <- 1:27
dim(arr) <- c(3,3,3)
arr

# Admissions to Berkley - an array example
UCBAdmissions 					# This is already loaded in R's memory
dimnames(UCBAdmissions) # This shows you the names of the dimensions in the array
UCBAdmissions[1,,] 			# Counts of males and females for each department
UCBAdmissions[,1,] 			# Counts ofadmitted and rejected for each department
UCBAdmissions[,,1]  		# Crosstab of gender-admission for department "A"
UCBAdmissions[,,"A"]

# Lists are vectors of other objects, and can contain elements of any type
lt <- list(UCBAdmissions, b, 1:10)
lt[[1]] 			# This contains UCBAdmissions
lt[[2]] 			# This contains our "b" matrix
lt[[3]] 			# This contains the sequence from 1 to 10
# We will not work with lists often in this course though

# Finally, we have data frames
# This is the type of object that you will use most as you will work with data
# Today's session will not regard data manipulation
# For the time being, it should be enough to know that data frames are tables
# where rows are assumed to be observations and columns variables
# Differently from a matrix, a data frame can contain different type of data
# in every column
data <- data.frame(col1 = 1:10,col2 = letters[1:10])
data
data[,1]
data[,2]
# However, with data frames it is more comfortable to call variables with column names
data$col1
data$col2
data[5,] 			# This selects one specific observation
# You can also use "cbind"
data <- data.frame(cbind(1:10,letters[1:10]))
data
# But then the variables will have different names
data$X1
data$X2
# You can change all variable names by
names(data) <- c("var1","var2")
data
# or a single variable name
names(data)[1] <- "newvar1"
data
# You can select a variable by its name using the "which" function
data[which(names(data)=="var2")]
# And rename it in the same way
names(data)[which(names(data)=="var2")] <- "newvar2"
data
# This last command will be extremely useful when we will work with data.


#############
# Functions #
#############
# All the operations that R performs are functions. They usually follow the form
# 	f(argument1, argument2, ...)  
# Of course, they can also be put into objects
f <- function(x,y){c(x+1,y+1)}
f(1,2)
# It will take any object as a single entry, even when it has more than 1 value
onetwo <- c(1,2)
f(onetwo) 		# Error: the function wants 2 entries, you gave only one object
threefour <- c(3,4)
f(onetwo,threefour)
# Often you can see the code for a function by typing its name
f
# This is very handy if you are trying to write a function and want to borrow
# some ideas from a similar one


# The most of the things that you ask R to do are functions
numbers <- (0:10)
sum(numbers) 				# Returns the sum of all the elements in "numbers"
length(numbers) 		# Returns how many values in the vector "numbers"
mean(numbers) 			# Returns the Mean, equivalent to
sum(numbers)/length(numbers)
var(numbers) 				# Returns the variance
sd(numbers) 				# Returns the Standard Deviation, equivalent to
sqrt(var(numbers))
median(numbers) 		# Returns the Median value
min(numbers) 				# Returns the Minimum value
max(numbers) 				# Returns the Maximum value
quantile(numbers) 	# Returns a number of quantiles of the distribution
# You can also ask for some specific quantiles
quantile(numbers,probs = c(0.025,0.975)) 

# A more complete function for creating sequences of numbers is "seq()"
seq(from = 1, to = 10, by = 0.5) # Gives you a sequence of numbers from 1 to 10, 
# with 0.5 increment
seq(from = 1, to = 2, length.out = 100) # Gives you a sequence of 20 numbers 
# from 1 to 100
# You can write it in the shorter form:
seq(1,100,2) # Sequence from 1 to 100 with increment = 2

# What if you need a sequence with the same number repeated n times?
rep(5,10) 		# Repeats the number 5 ten times
rep(1:3,10) 	# Repeats the sequence from 1 to 3 ten times

# A function for making cross-tables
# (crosstabs in R are particular types of array)
se.q <- rep(1:3,10)
table(se.q)
# How to see percentages?
table(se.q)/length(se.q)*100
se.q <- c(se.q,1:6)
table(se.q)/length(se.q)*100

# If you are bothered by many decimals, you can round numbers
tab <- table(se.q)/length(se.q)*100
tab
round(tab, digits = 1)
tab <- round(tab, digits = 1)
tab
sum(tab) 		# Although this way they may not sum up to 100

# Another useful function is "sample"
sequence <- seq(0,9,3)
sequence
sample(sequence, size = 2) # It samples twice from the population "sequence"

# The size of your sample can be even larger than your population
# but you will need to add the option "replace"
sample(sequence, size = 6, replace = T) 

# "replace" allows the sampler to take the whole population every time
# This means that the same element can appear more times

# You can also specify the probability for each element to be sampled
sample(c(0,1),size = 1,prob = c(0.5,0.5))  # A fair coin
sample(c(0,1),size = 1,prob = c(0.2,0.8))  # A less fair coin

# How fair is a fair coin?
trials <- sample(c(0,1),size = 1000,prob = c(0.5,0.5), replace = T)
table(trials)
table(trials)/length(trials)*100
mean(trials)

# A Russian roulette (1 = shot)
r.r <- sample(c(0,1), size = 1, prob = c(5/6,1/6))
r.r <- sample(c(0,0,0,0,0,1), size = 1, prob = rep(1/6,6))
r.r 		# I would have made it
# 100 trials
r.r <- sample(c(0,1), size = 100, prob = c(5/6,1/6), replace = T)
table(r.r)     
mean(r.r)
hist(r.r)

############
# Exercise #
############
# Roll a dice (with 6 faces) for 1000 times. Put your trials into an object
# called "dice". Make a table and a histogram of the results
# Use "?hist" to see how you can change the labels of the axis of the histogram
# Change the main title from "Histogram of dice" (the default) to "How to roll a dice"
# Change the name of the x-axis to "Outcome"





# Solution
dice <- sample(1:6, size = 1000, replace = T )
table(dice)
hist(dice,main="How to roll a dice",xlab="Outcome")
