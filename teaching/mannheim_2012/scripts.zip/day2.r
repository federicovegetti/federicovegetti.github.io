##########################
# Day 2 - Working with R #
##########################
rm(list=ls())

############
# Packages #
############
# The 99% of the reasons why we use R, is to do things with data.
# Of course R can create fake data, that we can use to run simulations or experiments,
# but working with actual data is what we normally prefer.
# So we should give it a look.

# R is not able to load data by itself. He will need a package to do it.
# What is a package?
# Generally speaking, a package is a set of functions, help files and data files that 
# have been put together and are somehow related to one another.

# R offers a lot of packages - right now the CRAN network has 4024 available packages!

# To see the packages that you have loaded at the moment you type
(.packages())

# To see all the packages that you have installed, and you can load in the library, you
# can type
(.packages(all.available = T))
# or
library() 		# This will open a new window though

# You will use the "library" function also to load a package in the library
library(foreign)
# In this way you are loading the package "foreign"
# Thie package allows you to read data from other formats, including Stata and SPSS
# An equivalent function is:
require(foreign) 		# You can generally use "library" and "require" interchangeably

# R does not load all the packages in the library because some of them may slow down the 
# execution significantly, and because some packages may use functions that have the same
# name but do different things. In such a case, when you call a function, R will not know
# which one you are referring to, and will return an error message.
# For this reason, some packages automatically un-load other packages that you have loaded
# before.

# However, a package may not be installed on the version of R that you have on your 
# computer.
# Example: the package "mvtnorm" is used to create multivariate normal and t distributions,
# and I bet is not there

install.packages("mvtnorm", dependencies = T)
# Some packages may build on other packages, i.e. they will use functions that are taken
# from other user-developed packages. That's why it is better (but not necessary) to set
# the option "dependencies = TRUE".
# The option "dependencies" tells R to search for all the packages that the one you want
# to install depends on, and install them on your computer as well.

# Notice that if you select the CRAN mirror in Wiesbaden, the download won't work.
# Probably the server is down, and the list of mirrors provided in the CRAN is not
# updated yet.

# You can also remove some packages that you don't need, using
remove.packages("mvtnorm")


#################################
# Loading and working with Data #
#################################

# First we set the working directory - we say R where he can find the dataset
setwd("C:\\Users\\Fede\\Desktop\\R course\\Day2") 	# change to your working directory
# or
setwd("C:/Users/Fede/Desktop/R course/Day2")
# (R does not really like the single backslash "\" when it gets to define directories,
# so we either double it, or we use the normal slash "/")

# From now on, for everything we ask R to load, he will assume it is in the directory we
# have specified
# Let's put the data into an object called "MyData" using the "read.dta" function
MyData <- read.dta("kidiq.dta")
# This function is used to read the Stata file format (.dta)
# Other functions are:
# read.spss() = reads data in the SPSS .sav format
# read.csv() = reads data in .csv format, produced also by Excel
# read.table() = reads data in .dat format, or tab delimited data also in .txt


# Note that we can also specify the address within the read.dta function, in case we work 
# data from several directories.
MyData <- read.dta("C:\\Users\\Fede\\Desktop\\R course\\Day2\\kidiq.dta")
ls()

# Once you have loaded the data, the first problem comes: how to see them?
# In SPSS the data view is as important as the variable view. Stata also offers the 
# possibility to see the data matrix in a window.
# However, with R it is not very intuitive.
# Calling the object will not help much, unless your dataset is very small
MyData

# To start, you can see what are the names of the variables in your dataset
names(MyData)

# However, in RStudio we can simply click on the object in the up-right panel. 
# This will call automatically the "View" function, which is what we are looking for
View(MyData) 	# This command will show you the data matrix in a new window

# The data is an extract from the American National Longitudinal Survey of Youth, and it 
# contains information about a sample of adult women and their children
# Here we find 3 variables:
# kid_score: iq test scores of 3 and 4-years-old children
# mom_hs: whether the mom of the kid completed the high school (1) or not (0)
# mom_iq: iq score of the mother
# mom_work: categorical variable about the mother's work, not clear to me - we won't use it
# mom_age: age of the mother

# Some descriptives
summary(MyData)
# The "summary" function gives you a very basic description of the distribution of the
# variables contained in the data set

# A fast way to check how many cases you have (with large datasets the "view" function 
# will show you only the first 1000 cases)
length(MyData[,1]) 	# This will show you the length of the vector consisting in the first
										# variable in your dataset. 
# Similarly, if you want to know how many variables you have, you can type
length(MyData[1,])  # which asks R to show you the length of the vector consisting in the
										# first case

MyData[,1]
# However, if you use RStudio, all these informations are displayed in the up-right panel

# However, the way to refer to variables in data frmes is with the dollar "$" sign
MyData$kid_score 		# will show you a vector consisting in the variable "kid_score"

# You can also refer to some particular cases, according to their values
MyData$kid_score[MyData$kid_score > 100]
MyData$kid_score[MyData$kid_score > 100 & MyData$kid_score < 120]
MyData$kid_score[MyData$kid_score == 100]

# The "subset" function helps a lot in clarifying the cases/variables selection
subset(MyData, kid_score > 110, select = c(mom_iq, mom_hs))
# This returns a data set containing only the variables "mom_iq" and "mom_hs" and 
# the observations where the kid scores higher than 110

# Some descriptives for kid_score
mean(MyData$kid_score)
sd(MyData$kid_score)
min(MyData$kid_score)
max(MyData$kid_score)
max(MyData$mom_iq)
# Interestingly enough, there's a kid who's smarter than any mother

summary(MyData$kid_score)

######################
# Visualize the data #
######################
# histograms are the classic 
hist(MyData$kid_score,col = "blue", main = "", xlab = "Kids' IQ scores", freq = F)
hist(MyData$mom_iq,col = "blue", main = "", xlab = "Mothers' IQ scores")
hist(MyData$mom_age,col = "red", main = "", xlab = "Mothers' age")

# You can set the limits of the x and y axes, to compare the kid IQs qith the mother IQs
hist(MyData$kid_score,col = "blue", main = "", xlab = "Kids' IQ scores",xlim = c(20,145))
hist(MyData$mom_iq,col = "blue", main = "", xlab = "Mothers' IQ scores",xlim = c(20,145))

# You can plot the two variables next to each other to make a more direct comparison
par(mfrow=c(1,2)) 		# The "par" function is used here to set the number of rows (1) and 
											# columns (2) of our graphic display
hist(MyData$kid_score,col = "blue", main = "Kids", xlab = "IQ scores", 
		 xlim = c(20,145), ylim = c(0,0.025), freq = F)
hist(MyData$mom_iq,col = "blue", main = "Mothers", xlab = "IQ scores", 
		 xlim = c(20,145), ylim = c(0,0.025), freq = F)
# The two histograms are perfectly comparable (same length for x and y axes)
# What can we tell about the data in the figure?

# The "par" function can set many graphic parameters. Many options that it contains can 
# be called inside of the plotting command (see the "col" in my hist call above)
# Check ?par for a list of the possible options
?par
############
# Exercise #
############
# 1.
# We saw that there is at least one kid with the impressive iq of 144. We are curious to 
# find out some characteristics of the mother.
# What's her IQ? 
# Does it correspond to the highest mother's IQ in our sample?
# Is it above the mean of the mothers' IQ in our sample?
# Did she complete the high school or not? 
# What is her age?
# Is the older or younger of the mean?

# Here again a description of the variables:
# mom_hs: whether the mom of the kid completed the high school (1) or not (0)
# mom_iq: iq score of the mother
# mom_age: age of the mother
MyData$mom_iq[MyData$kid_score == 144]
max(MyData$mom_iq)
mean(MyData$mom_iq)

MyData$mom_hs[MyData$kid_score == 144]

MyData$mom_age[MyData$kid_score == 144]
mean(MyData$mom_age)


# 2.
# Find out the mean and the standard deviation of the mothers' IQ for 2 groups 
# of children:
# Group 1: those who have an IQ bigger than 100
# Group 2: those who have an IQ smaller than 100





mean(MyData$mom_iq[MyData$kid_score > 100])
sd(MyData$mom_iq[MyData$kid_score > 100])
mean(MyData$mom_iq[MyData$kid_score < 100])
sd(MyData$mom_iq[MyData$kid_score < 100])

# 3.
# Make two histograms (one next to the other in the same picture) for these two variables
# Try to make them as much comparable as possible (e.g. same range for x and y axes)
par(mfrow=c(1,2)) 
hist(MyData$mom_iq[MyData$kid_score > 100],col = "blue", main = "Kid's IQ > 100", xlab = "Mother's IQ score", 
		 xlim = c(20,145), ylim = c(0,0.03), freq = F)
hist(MyData$mom_iq[MyData$kid_score < 100],col = "blue", main = "Kid's IQ < 100", xlab = "Mother's IQ score", 
		 xlim = c(20,145), ylim = c(0,0.03), freq = F)






##########################################################
# More on plotting and visualizing data (and some stats) #
##########################################################
# We want to know whether the mother having a high school degree can influence her kid's
# IQ

table(MyData$mom_hs)/length(MyData$mom_hs)
# More than the 78% of our mothers here completed the high school
# How to have some idea whether this makes a difference for children IQ?

# Compare means
mean(MyData$kid_score[MyData$mom_hs == 0])
mean(MyData$kid_score[MyData$mom_hs == 1])

# You can do it in one line with the "tapply" function
tapply(MyData$kid_score, INDEX = MyData$mom_hs, FUN = mean)

# Two histograms
par(mfrow=c(1,2)) 
hist(MyData$kid_score[MyData$mom_hs == 0],col = "blue", main = "Mother not completed high school", xlab = "IQ scores", 
		 xlim = c(20,145), ylim = c(0,0.025), freq = F)
hist(MyData$kid_score[MyData$mom_hs == 1],col = "blue", main = "Mother completed high school", xlab = "IQ scores", 
		 xlim = c(20,145), ylim = c(0,0.025), freq = F)


# We can make a plot
par(mfrow=c(1,1))
plot(y = MyData$kid_score, x = MyData$mom_hs)

# or a nicer plot
par(mfrow=c(1,1))
plot(y = MyData$kid_score, x = jitter(MyData$mom_hs, amount = 0.05), 
		 pch = 20, xaxp = c(0,1,1), ylim = c(0,150), las = 3,
		 ylab = "Child IQ", xlab = "Mother completed the High School")

# "pch" refers to the type of point. You can find a list of possible plotting points here:
# http://rgraphics.limnology.wisc.edu/images/miscellaneous/pch.png

# "xatp" is a vector that gives the coordinates of the extreme tick marks and the interval
# between them

# "las" refers to the style of the axis labels. "1" means always horizontal.
# All these options are described in ?par

# Finally "jitter" adds some disturbance around the values. I used it to make the points
# more distinct. Since the disturbance is random, the plot will look different every time
# you call it


# We can perform a t-test
t.test(MyData$kid_score ~ MyData$mom_hs)


# By hand (mean group 2 bigger than mean group 1)
m.dif <- mean(MyData$kid_score[MyData$mom_hs == 0]) -         # Mean goup 1
				 mean(MyData$kid_score[MyData$mom_hs == 1]) 					# Mean goup 2
m.dif

se <- sqrt( (var(MyData$kid_score[MyData$mom_hs == 0]) / 			# Variance group 1
						 length(MyData$kid_score[MyData$mom_hs == 0])) + 	# N cases group 1
	 				  (var(MyData$kid_score[MyData$mom_hs == 1]) / 			# Variance group 2
	 				   length(MyData$kid_score[MyData$mom_hs == 1])) )	# N cases group 2

myttest <- m.dif/se
myttest
# compare the result to the t.test function
rttest <- t.test(MyData$kid_score ~ MyData$mom_hs)
rttest
# Once we put the outcome of a test into an object, we can select only some "pieces" of it
rttest[1:9] 		
# Here we care about the first element of the object, the t-statistic
rttest[1]
# But we can also use the dollar sign
rttest$statistic

# Is it the same as our result?
rttest$statistic == myttest


# We are too lazy to compute the degrees of freedom and to check on the table for the 
# staistical significance. We will trust R.




############
# Exercise #
############
# 1.
# Use the "par" function to set the visualization parameter back to one single panel 
# (i.e. 1 row, 1 column)
par(mfrow=c(1,1))

# 2.
# Make a plot with the mother's age on the x axis, and the kid's IQ on the y
# Use "ylim" and "xlim" to set the ranges of the axes, to make the cloud of points appear
# around the center of the plot. You can check for the minimum and maximum mother's age 
# to set the limits
# Label the y axis as "Child IQ", and the x axis as "Mother's Age"
plot(y = MyData$kid_score, x = MyData$mom_age, pch = 20, ylim = c(0,150), xlim = c(15,30), 
		 las = 1, ylab = "Child IQ", xlab = "Mother's Age")








#########################################################
# Creating new variables and recoding the existing ones #
#########################################################
# We want to create a dummy that is equal to 1 if the IQ of the mother is bigger than or
# equal to 100, and 0 otherwise
MyData$mom.iq.hi <- NA
MyData$mom.iq.hi
MyData$const <- 1 

MyData$mom.iq.hi[MyData$mom_iq >= 100] <- 1
MyData$mom.iq.hi[MyData$mom_iq < 100] <- 0

table(MyData$mom.iq.hi)
round(table(MyData$mom.iq.hi)/length(MyData$mom.iq.hi), digits = 2)
summary(MyData$mom.iq.hi)

# We may want to create categories, say age classes
# Let's try with the variable mom_age
summary(MyData$mom_age)
hist(MyData$mom_age)
# We want 3 categories here:
# 1 = from lowest to 21
# 2 = from 22 to 24
# 3 = from 25 to highest

MyData$momage.cat <- NA
MyData$momage.cat[MyData$mom_age <= 21] <- 1
MyData$momage.cat[MyData$mom_age > 21 & MyData$mom_age < 25] <- 2
MyData$momage.cat[MyData$mom_age >= 25] <- 3

table(MyData$momage.cat, MyData$mom_age)

# The "cut" function works even better for this purpose
MyData$momage.cat.alt <- cut(MyData$mom_age, breaks = c(-Inf,21,24,Inf), 
														 labels = c(1,2,3), right = T)
table(MyData$momage.cat.alt, MyData$momage.cat)


# Maybe we want to create some variables that are obtained through operations between 
# other variables
# Example, we may want to know about the difference in IQ between the mother and the child
MyData$diff.iq <- MyData$mom_iq - MyData$kid_score
hist(MyData$diff.iq, col = "maroon")
# it looks like there are some kids that are actually smarter than their mother


# In some cases, we may want to select observations that are not missing for certain
# variables (i.e. to have equal samples for comparative model fit tests)
# Here we don't have missing observations, but we can create them.
# let's do it for "kid_score" and "mom_iq"
MyData$kidscore.new <- MyData$kid_score
MyData$momiq.new <- MyData$mom_iq

# Let's select randomly about 10% of observations to turn into NA
cases <- c(1:length(MyData$kidscore.new))
mis.cases1 <- sample(cases,43, replace = F)
# Resample and redo the same for momiq.new
mis.cases2 <- sample(cases,43)

MyData[mis.cases1,"momiq.new"] <- NA
MyData[mis.cases2,"kidscore.new"] <- NA

summary(MyData$kidscore.new)
summary(MyData$momiq.new)

#Are there cases where they are both missing?
MyData[is.na(MyData$momiq.new) & is.na(MyData$kidscore.new),]


# the function "is.na" indicates which elements of a vector are missing
# we can use it to select observations

# How to select all those cases that are missing neither in kidscore.new nor in momiq.new?
new.data <- MyData[!is.na(MyData$momiq.new) & !is.na(MyData$kidscore.new),]
summary(new.data)
summary(new.data$kidscore.new)
summary(new.data$momiq.new)

# How many cases did it drop?



######################
# Save your data set #
######################
# Of course, with R we can also save data sets in the format that we prefer.
# The "foreign" package allows us to write in Stata, SPSS, SAS and csv format

# to Stata
write.dta(new.data,"newdata.dta")

# to SPSS
write.foreign(new.data,"C:/Users/Fede/Desktop/R course/Day2/newdata.txt", 
							"C:/Users/Fede/Desktop/R course/Day2/newdata.sps", package = "SPSS")
# Actually, this routine exports it into a text datafile and creates an SPSS syntax that
# reads it 
# However, so, since in the syntax .sps file there will be the address of the text .txt 
# file, in order to let SPSS find it you will need to provide the complete path

# R can also save your workspace (i.e. your working environment, consisting in a 
# collection of all the objects that you have defined)
# The general command (if you have already set the working directory before) is:
save.image("MyWorkspace.RData")

# You can load the workspace in the future, by using the "load" command
load("MyWorkspace.RData")



############
# Exercise #
############
# 1.
# Let's go back to the cases where the kid scores higher than the mother
# Create a dummy called smart.kid, which is 1 for those cases, and 0 otherwise
# How many are they?
# What's is their proportion in the sample?

MyData$smart.kid <- NA
MyData$smart.kid[MyData$diff.iq >= 0] <- 0
MyData$smart.kid[MyData$diff.iq < 0] <- 1
table(MyData$smart.kid)
table(MyData$smart.kid)/length(MyData$smart.kid)


# 2.
# Use the "tapply" function (we have seen it above, see ?tapply) to see the mean mother's
# age for each of the two groups of kids
# Are the mothers of the smartest kids younger than the mothers whose kids have an IQ lower
# than their own?

tapply(MyData$mom_age, INDEX = MyData$smart.kid, FUN = mean)

# 3.
# Make two plots, both with the smart.kid dummy on the x axis.
# On the y axis you put the mother's IQ in the first, and the child's IQ in the second
# Are the mothers of the smarter children scoring particularly low in IQ compared to the
# other mothers, or are the smarter children who score particularly high compared to the
# other children?
# Also, run two t-tests to see whether there are significant differences, and for which 
# of the two possibilities the t-statistic is bigger

par(mfrow = c(1,2))
plot(y= MyData$mom_iq, x = jitter(MyData$smart.kid,amount = 0.05), pch = 20, 
		 ylim = c(20,150),xaxp = c(0,1,1), ylab = "Mother's IQ", xlab = "", las = 1)
plot(y= MyData$kid_score, x = jitter(MyData$smart.kid,amount = 0.05), pch = 20,
		 ylim = c(20,150),xaxp = c(0,1,1), ylab = "Kid's IQ", xlab = "", las = 1)

t.test(MyData$mom_iq ~ MyData$smart.kid)
t.test(MyData$kid_score ~ MyData$smart.kid)








#############################
# Probability distributions #
#############################
# As the "sample" function shows, R is able to select random numbers from a sequence
# R is also able to create random distributions

# What is a distribution? 
# A probability distribution is a set of values, normally generated by a random experiment
# (intended with the definition used in probability theory, i.e. a procedure that leads to 
# a set of outcomes and that can be repeated potentially an infinite number of times)
# In a probability distribution, each outcome is associated with a probability.
# For example, in a normal distribution the highest probability peak ( or "density") is 
# around the mean. This means that if we take a randome sample from a normal distribution,
# the probability that we will pick up an outcome around the mean will be the highest, and 
# it will become smaller and smaller the more a value gets far from the mean.

# We'll see how this works soon.

# R can generate several types of distribution. You can have a more clear idea by typing
??distribution
# or
help.search("distribution")
# or, of course, by googleing something like "r distribution"

# Generate a random normal distribution
# "rnorm" generates a continuous normal distribution
normal <- rnorm(1000, mean = 5, sd = 1)
hist(normal, col = "red") 		# You can change color for the spikes
mean(normal)
sd(normal)
quantile(normal,p = c(0.025,0.975)) 			# Here's the confidence interval

# "dnorm" returns the height of the probability distribution for each point
# by default, R assumes mean 0 and standard deviation of 1
dnorm(0)
# As the standard deviation increases, the probability to have an observation
# around the mean decreases
dnorm(0,sd=2)
dnorm(0,sd=3)
dnorm(0,sd=4)
# Moreover, if the location of the mean changes, the probability of 0 decreases
dnorm(0,mean=3)
# Unless the dispersion becomes bigger
dnorm(0,mean=3,sd=2)

x <- 0:2
x
dnorm(x)
dnorm(x,mean=1)
dnorm(x,mean=1,sd=2)

# Let us combine our "normal" distribution and its density at each point
dens <- dnorm(normal, mean = 5, sd = 1) 
# We had to specify again the mean and the sd to avoid that R assumes mean = 0  & sd = 1
normal <- cbind(normal,dens)
# Let us plot this
plot(x = normal[,1], y = normal[,2])

# Another example
x <- -10:10
y <- dnorm(x)
plot(x = x, y = y, pch = 20) 			# "pch" is a graphic parameter to change points
# What if we increade the standard deviation?
y <- dnorm(x,sd=2)
plot(x = x, y = y, pch = 20)
# what if we change the mean?
y <- dnorm(x,mean=5)
plot(x = x, y = y, pch = 20)

# "runif" is similar to "rnorm", but it will generate a uniform distribution
# i.e. the probability is distributed uniformly along the specified range
unif <- runif(10000, min = 0, max = 10)
mean(unif)
hist(unif, col = "blue")

# "dunif" is its density counterpart
dunif(0)
dunif(1)
x <- seq(from = -2, to = 2,by=0.05)
y <- dunif(x)
plot(x = x, y = y, pch = 20)
# It assumes a range from 0 to 1: everything in that range has equal probability
# (which changes depending on the number of observations), everything out of that
# range has probability = 0
# Let's plot the density of the uniform distribution generated with "runif"
unif.dens <-  dunif(unif,min = 0, max = 10)
unif <- cbind(unif, unif.dens)
plot(x = unif[,1], y = unif[,2])
# notice that for each point the probability is constant at 100/1000
# What if we specify a different range for the probability distribution?
unif.dens.2 <-  dunif(unif,min = -5, max = 5)
unif <- cbind(unif, unif.dens.2)
plot(x = unif[,1], y = unif[,3])


