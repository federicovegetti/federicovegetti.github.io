#########
# Day 3 #
#########

#########################################
# A few things more about R programming #
#########################################

# OBJECTS, AGAIN

# VECTORS REFRESHER
# Atomic VECTORS = vectors containing elements of the same type
# R has 6 atomic vector types:
# logical, integer, double, complex, character, raw

# A logical vector
c(TRUE,FALSE,TRUE)
# or
c(T,F,T)
is.logical(c(T,F,T))	# the answer ([1] TRUE) will be a logical 
											# vector itself, of length 1

# Integer and Double both refer to numerical vectors
# However, if you specify "numeric", R will assume 
# "double" (or "double-precision") vectors
# A numerical vector
c(1,2,3,4,5)
is.numeric(c(1,2,3,4,5))
is.double(c(1,2,3,4,5))
is.integer(c(1,2,3,4,5))  # FALSE: when you create a numeric 
													# vector, R assumes a "double" type
as.integer(c(1,2,3,4,5))	# looks the same, doesn't it?
# You do not need to care about this distinction

# A Character (or string) vector
c("a","b","c","d","e")
is.character(c("a","b","c","d","e"))

# Finally, Complex vectors refer to complex numbers, and Raw vectors 
# refer to raw bytes.
# We do not need them - at the end of the day we will just use
# "numeric" (or "double") types and character (or "string") types

# LISTS REFRESHER
# They are generic vectors: they are like vectors, but the elements
# they contain do not have to be the same type
list(c(1,2,3),"a","another object")
# NOTE: outputs of regression models are lists

# FUNCTIONS REFRESHER
function(x,y){x+y}
# Everything that R does is a function.
# Even "<-"
`<-`   
b <- 2
`<-`(b,2)
b
# Here "b" and "1" are the arguments of the function

# Another example: the sum ("+") function
3+3
`+`(3,3)
# or
sum(3,3)

# SOMETHING NEW ON SPECIAL VALUES
# R has some special values that you will meet some time during your
# data munging.

# NA : this is a missing value, as "." in Stata
somedata <- c(1,2,3)
length(somedata) <- 4
somedata  # if the length of a vector is bigger than the data that you
					# have, R will plug a NA 

# Inf and -Inf
# Sometimes numbers are just too big
2^1024
-2^1024
# Or, if you divide by zero
1/0

# NaN : not a number
# Something does not make sense
0/0
Inf - Inf

# NULL : just a null object, the emptyness
NULL
NULL + 1
c(NULL , 1, 2, 3)

###
# CONTROL STRUCTURES #
# The following commands are useful programming tool that you will use 
# to transform your data, as well as analyzing them and even plotting
# them
# These operators can be written as functions, but it is more intuitive
# to keep them in extended syntax structure
# Two of them are particularly important:

# 1. CONDITIONAL STATEMENTS
# 1.1 IF statement
# the general form is:
# if (condition) true_expression else false_expression
# "true_expression" is what R returns in case the logical value 
# returned by the evaluation of the input given the condition is TRUE
# "false_expression" is for when it is false
a <- 1
# let's create a "b" which has 50% probability to be bigger than "a"
b <- sample(c(0,2),1,p=c(0.5,0.5))
if(b>a)"b is bigger than a" else "a is bigger than b"
# Here the function evaluates whether the input respects the condition
b>a 	# and returns a logical value
# the statement right after the condition is returned in case of TRUE
# of course the statement can be a function as well

# Super trivial example
if(5==4)1+1 else 2+2

# A bit less trivial
a <- sample(c(-1,1),1,p=c(0.5,0.5))
b <- sample(c(-1,1),1,p=c(0.5,0.5))
if(a==b)a+b else a-b

# You can create nested if/else statements
a <- sample(c(-1,1),1,p=c(0.5,0.5))
b <- sample(c(-1,1),1,p=c(0.5,0.5))
if(a==b)if(a<0) abs(a+b) else a+b else a+b
# should be always 2 if a == b and 0 if a != b

# IF does not work with vectors, i.e. if there is more than 1 logical
# value in the "condition" statement, R will evaluate only the first
# (and give you a Warning)
a <- 0
b <- c(-5:5)
if(a>b)"b is smaller than zero" else "b is bigger than zero"
# it will always return "b is smaller than zero" because it will 
# evaluate only the 1st element of b, which is -5


# 1.2 IFELSE statement
# "ifelse" works more like a conditional selection, and unlike "if", 
# it works with vectors.
a <- 0
b <- c(-5:5)
ifelse(a>b, "b is smaller than zero", "b is bigger than zero")
# There is something wrong here, but we'll go back to it later

# This is pretty useful for data cleaning, too
data <- data.frame(rnorm(mean=0,sd=1,n=20), c(1:20))
names(data) <- c("var1", "var2") # "var2" is actually useless here
mean(data$var1)
data$var3 <- ifelse(data$var1 > 0, 1, -1)
# Here var3 is equal to 1 if var1 is bigger than 0, and is equal to
# -1 otherwise
View(data)

# 2. LOOPS
# Loops can be the only way to recode some variables or to create some
# new ones. They look difficult, but they are not.
# There are 3 different looping structures:

# 2.1 REPEAT
# This repeats the same expression. Conceptually It's similar to the 
# rep() function. You can use the command "break" to interrupt it

i <- 0 			# This object works as an index, necessary for every loop
repeat{if (i <= 25) {print(i); i <- i + 5} else break}
# If we didn't use the command "break" here, the loop would be infinite
# Never found a "repeat" loop useful though.

# 2.2 WHILE
# Now we talk. the "while" loop repeats an expression while a certain 
# condition is true
i <- 1
while(i <= 100){
	a[i] <- i
	i <- i + 1
}
print(a)

# let's go back to our data
data <- data.frame(rnorm(mean=0,sd=1,n=20), c(1:20))
names(data) <- c("var1", "var2")  # This time let's work with "var2"
i <- 1
while(i <= 20){
	data$var3[data$var2 == i] <- i + 100
	i <- i + 1
}
View(data)

# The Fibonacci Sequence: each number is the sum of the two previous 
# ones, given the first two numbers, 0 and 1.
# If you read the DaVinci Code you will know about it. Otherwise, check
# it on Wikipedia.
# Let's try to do it with a "while" loop
i <- 1
im1 <- 1
im2 <- 0
fib.seq <- NULL
fib.seq[1] <- im2
fib.seq[2] <- im1
while(i <= 18){
	fib.seq[i+2] <- im1 + im2
	temp <- im1
	im1 <- im1 + im2
	im2 <- temp
	i <- i + 1
}
fib.seq
fib.seq[20] == (fib.seq[18] + fib.seq[19]) 		# Yeah


# 2.3 FOR
# FOR loops are the most commonly used if you work with data
# With "for" you will basically loop through each item in a vector
random.vector <- c(2,5,13,0.5,8,100)
for(i in random.vector){
	print(i^2)
}
# Notice that the results are not printed from within a loop, unless it
# is explicitly asked
for(i in random.vector){
	i^2
}
# ^ this won't show you anything

# Moreover, in this case we didn't define "i" as a variable, but it is
# created by the loop, and it is changed automatically from within it.
# Thus, at the end, it will have the value of the last element of the
# vector
i
random.vector

for (i in data$var1) {
	data$var4[data$var1 < 0] <- -1
	data$var4[data$var1 == 0] <- 0
	data$var4[data$var1 > 0] <- 1
}
View(data)
# Which is the same as what we did before with the ifelse statement



############
# Exercise #
############
# Taks 1
a <- 0
b <- c(-5:5)
ifelse(a>b, "b is smaller than zero", "b is bigger than zero")
# Let's compare them to find what is wrong
c <- ifelse(a>b, "b is smaller than zero", "b is bigger than zero")
cbind(b,c)
# Here's the problem:
# it returns "b is bigger than zero" even when "b" is actually 
# equal to zero. We don't like this.
# Rewrite this statement, but with 3 conditions:
# if b < a the output should be "b is smaller than zero"
# if b == a the output should be "b is equal to zero"
# if b > a the output should be "b is bigger than zero"

# Taks 2
# Given the following data:
data <- data.frame(1:100)
names(data) <- "var1"
View(data)
# Use a "while" loop to create a variable "var2" that
# is the sum of all the values in "var1" up to that point. 
# Imagine it like a cumulation of all the values of "var1".

# This is how the data should look like:
#			var1	var2
#	1		1			1					
# 2		2			3					i.e. 2 + 1
# 3		3			6					i.e. 3 + 2 + 1
# 4		4			10				i.e. 4 + 3 + 2 + 1
# 5		5			15				i.e. 5 + 4 + 3 + 2 + 1
# 6		6			21				i.e. 6 + 5 + 4 + 3 + 2 + 1
# and so on...

# Tip: if the loop runs for more than a fraction of second, there is
# something wrong.




# Solutions
# Task 1
c <- ifelse(b<a,"b is smaller than zero",ifelse(b==a,"b is equal to zero","b is bigger than zero"))
cbind(b,c)
# Task 2
i <- 1
while(i <= 100){
	data$var2[data$var1 == i] <- sum(data$var1[data$var1 == 1]:data$var1[data$var1 == i])
	i <- i + 1
}
View(data)



#####################################
# Going deeper into data management #
#####################################
# MERGING DATA
# What if we have 2 data sets with the same variables but different
# cases, and we want to merge them?

# Let's give an example with some European Election Study data
# EES is a survey conducted after the EU Parliament election in all
# EU countries, on a representative sample of the population
# (or at least that's what we like to believe)
# Here we are going to use the surveys conducted in Germany and Hungary
# after the 2009 election.

rm(list=ls())
library(foreign)
setwd("C:/Users/Fede/Desktop/R course/Day3")
EES.DE <- read.dta("EES2009_de.dta") 		# German EES
EES.HU <- read.dta("EES2009_hun.dta")		# Hungarian EES

summary(EES.DE)
summary(EES.HU)
# As we see, there are 4 variables more in the Hungarian file
# That's because of the "ptv" variables, that in Hungary are asked
# about more parties than in Germany

# For this reason, the classic "rbind" won't work
EES.new <- rbind(EES.DE,EES.HU)
# Thus, we will need first to create the variables that are missing
# in EES.DE
# (we could also drop the exceeding ones in EES.HU, but we may need 
# them)
setdiff(names(EES.HU),names(EES.DE))
# ^ this is a set operator, which says what elements in the set of the 
# variable names in EES.HU are not at the same time present in the set
# of the variable names in EES.DE
# Since it's sensitive to the order, it won't work the other way round
setdiff(names(EES.DE),names(EES.HU))
# Fortunately we know that one dataset has more variables than the other

# Let's create the variables
EES.DE$ptv6 <- NA
EES.DE$ptv7 <- NA
EES.DE$ptv8 <- NA
EES.DE$ptv9 <- NA

# Now we can combine them
EES.new <- rbind(EES.DE,EES.HU)

# However, we figured that we do not have the "vote intention" variable,
# (very likely to happen with an elecoral survey), but we have it in 
# another file
EES.DE.VOT <- read.dta("EES2009_de_vot.dta")
EES.HU.VOT <- read.dta("EES2009_hun_vot.dta")

summary(EES.DE.VOT)
table(EES.DE.VOT$vote_int)
summary(EES.HU.VOT)
table(EES.HU.VOT$vote_int)

# We want to add this variable to our file
# We need a "key", a common variable between the two fields
intersect(names(EES.new),names(EES.DE.VOT))
intersect(names(EES.new),names(EES.HU.VOT))
# Looks like "id" is present in all of them

# Let's try to merge them
EES.new <- merge(x = EES.new, y = EES.DE.VOT, 
								 by = intersect(names(EES.new),names(EES.DE.VOT)))
# The "merge" function is useful when we have a common variable between
# the two data sets, and we want to use it to assign the values to the
# different observations
# With "cbind", it would just add the observations without matching them

# However, something went wrong.
# Now the EES.new dataset has 1004 observations, like EES.DE and 
# EES.DE.VOT

# Obviously, "merge" drops the cases that don't match with the "id"
# variable

#############
# Excercise #
#############
# Solve this problem
# The final data set should have 2009 observations and 23 variables





# Solution (one of the possible)
EES.DE.new <- merge(x = EES.DE, y = EES.DE.VOT, 
								 by = intersect(names(EES.DE),names(EES.DE.VOT)))
EES.HU.new <- merge(x = EES.HU, y = EES.HU.VOT, 
										by = intersect(names(EES.HU),names(EES.HU.VOT)))
EES.new <- rbind(EES.DE.new,EES.HU.new)
rm(EES.DE.new,EES.HU.new)


# SUMMARIZING AND TRANSFORMING DATA
# TAPPLY and BY

# We already met TAPPLY
# Still, let's use it here for an astonishingly interesting research 
# question: What is the average left-right position of people from 
# different social classes?

# We have a left-right self placement variable
summary(EES.new$resc_lrsp)
hist(EES.new$resc_lrsp,col = "red", freq = F)

# We have a categorical variable for social class
table(EES.new$class)
# It's meant to be categorical. Values are:
# 1 = working class
# 2 = low-middle class
# 3 = middle class
# 4 = upper-middle class
# 5 = upper class

# let's see the means
tapply(EES.new$resc_lrsp, INDEX = EES.new$class, FUN = mean)
# sad


# missings are not easy to handle in R
tapply(EES.new$resc_lrsp, INDEX = EES.new$class, FUN = mean, na.rm = T)

# the function "fivenum" gives a better hunch of the distribution
tapply(EES.new$resc_lrsp, INDEX = EES.new$class, FUN = fivenum)

# We can expand "tapply" to multiple dimensions
# how does this change between Germany and Hungary
tapply(EES.new$resc_lrsp, INDEX = list(EES.new$sys_name,EES.new$class),
			 FUN = mean, na.rm = T)
# Looks like Hungary was slightly more right-wing than Germany in 2009, 
# upper class aside


# "by" is similar to "tapply", it just shows the result in a different
# way
by(EES.new$resc_lrsp, INDICES = list(EES.new$sys_name,EES.new$class),
	 FUN = mean, na.rm = T)


# This does not necessarily have to be a descriptive job, i.e. we can 
# use similar functions to transform the data

# We may want to "center" the left-right position of each respondent
# around his/her country sample mean
means <- tapply(EES.new$resc_lrsp,INDEX = EES.new$country_n,FUN = mean, na.rm = T)
EES.new$lrmean[EES.new$country_n == 10] <- means["10"]
EES.new$lrmean[EES.new$country_n == 12] <- means["12"]


table(round(EES.new$lrmean, digits= 3))



# You can also do it in a loop (in case you have more than 2 countries)
for (i in c(10,12)) {
	EES.new$lrmean[EES.new$country_n == i] <- means[names(means)==i]
}
table(EES.new$lrmean)

EES.new$lrsp.new <- (EES.new$resc_lrsp - EES.new$lrmean)
summary(EES.new$lrsp.new)

hist(EES.new$lrsp.new,col = "red", freq = F)

# Histogram of Germany and Hungary
par(mfrow = c(2,2))
for (i in c(10,12)) {
	hist(EES.new$resc_lrsp[EES.new$country_n == i], col = "red", freq = F,
			 xlab = "L-R self placement", main = "", las = 1,
			 breaks = 20)
	title(main = unique(EES.new$sys_name[EES.new$country_n == i]))
}
for (i in c(10,12)) {
	hist(EES.new$lrsp.new[EES.new$country_n == i], col = "red", freq = F,
			 xlab = "Centered L-R self placement", main = "", las = 1,
			 breaks = 20)
	title(main = unique(EES.new$sys_name[EES.new$country_n == i]))
}



# SORTING AND RANKING DATA
# Sometimes, you just need observations to be sorted, or you want to 
# rank them for whatever reasons (say, you want to plot the effect of 
# education on attitudes towards immigration in several countries, and
# you want to sort the countries by level of income).
#
# R is not super intuitive when it gets to sort or rank data, so you
# may find an introduction about this point useful for the future
#
# First of all, R has a "sort" function
a <- c(4,2,9,5,1,7,3)
a
sort(a)
sort(a,decreasing = T)
# if you want to take NAs into account
length(a)
length(a) <- 8  # Increase length to add 1 NA
a
sort(a)
sort(a, na.last = T)
sort(a, na.last = F)

# Ok, nice, but does not help with the data
# That will be more problematic though
# More specifically, what we need is a function that generates a 
# permutation of the indices from the data, and use this to rearrange
# the rows in the correct order

# The function "order" may be better for us
a <- c(10,11,14,13,12)
order(a)
# The output means: "move the first element (10) to position 1, 
# the second (11) to position 2, the third (14) to position 5,
# the fourth (13) to position 4, and the fifth (12) to position 3".

# We can tell R to arrange the elements according to this ordering
# via index
a[order(a)]
# Now "a" looks sorted

# We can use this intuition to sort data
b <- letters[1:5]
ab <- data.frame(a,b)
ab
# We want to sort "ab" by "a"
ab[order(a),]   # Notice the comma: we are referring to rows

# We can apply this to real data

Example.data <- EES.DE[c(1:10),c("age","id","ptv1")]
View(Example.data)

# We want to order it by "age"
sorted.data <- Example.data[order(Example.data$age),]
View(sorted.data) 
# ^ notice the "row.names" variable, which keeps track of the previous
# index order

# We can also sort it by two different variables, for example by "ptv1"
# (the propensity to vote for the CDU, going from 1 to 10) AND by "age"
sorted.data <- Example.data[order(Example.data$ptv1, Example.data$age),]
View(sorted.data)




############
# Exercise #
############
# We have 3 variables: 
# polint = interest for politics, 4 gategories from 0 to 1
summary(EES.new$polint)
# close_dummy = whether the respondent feels attached to a party
table(EES.new$close_dummy)
# country_n = A country indicator. You can see what number corresponds 
# to what country by crossing it with sys_name, the string variable
# with the country name
table(EES.new$sys_name,EES.new$country_n)

# We want to see whether people who feel a partisan attachment are 
# also more interested in politics, and whether this relationship
# is the same in Germany and Hungary. 
# We can do it in two ways: 
# 1. check the difference in means using tapply()
# 2. checking the full distribution for the four categories using 
# hist()

# I want you to do it in both ways.
# Use the examples above to return 4 mean values using tapply() and to
# plot 4 histograms, one for each category, in the same figure.
# The figure should be easy to understand, so label it properly





# Solutions #
tapply(EES.new$polint,INDEX=list(EES.new$close_dummy, EES.new$sys_name),FUN = mean, na.rm = T)

par(mfrow = c(2,2))
hist(EES.new$polint[EES.new$country_n == 10 & EES.new$close_dummy == 0],
		 freq = T, col = "blue", las = 1, xlab = "Not Partisans", main = "" )
title(main = unique(EES.new$sys_name[EES.new$country_n == 10]))
hist(EES.new$polint[EES.new$country_n == 10 & EES.new$close_dummy == 1],
		 freq = T, col = "blue", las = 1, xlab = "Partisans", main = "" )
title(main = unique(EES.new$sys_name[EES.new$country_n == 10]))
hist(EES.new$polint[EES.new$country_n == 12 & EES.new$close_dummy == 0],
		 freq = T, col = "blue", las = 1, xlab = "Not Partisans", main = "" )
title(main = unique(EES.new$sys_name[EES.new$country_n == 12]))
hist(EES.new$polint[EES.new$country_n == 12 & EES.new$close_dummy == 1],
		 freq = T, col = "blue", las = 1, xlab = "Partisans", main = "" )
title(main = unique(EES.new$sys_name[EES.new$country_n == 12]))


