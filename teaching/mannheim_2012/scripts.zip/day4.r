#########
# Day 4 #
#########


#####################################
# More on statistical distributions #
#####################################
rm(list=ls())

install.packages("mvtnorm")
install.packages("MASS")
library(mvtnorm)
library(MASS)


# How to get a multivariate normal distribution

# First, we need to specify a variance/covariance matrix that R can 
# use to determine to what extent the (two or more) variables that we
# want to create are correlated
vcov <- matrix(c(1, .5, .5, 1), nrow=2, ncol=2)
print(vcov)
# Here we are specifying a standard deviation = 1 for each variable
# and a correlation = 0.5 between them

# Second, there are a couple of functions, in the two packages we just loaded,
# to generate random multivariate normal distributions
help("rmvnorm", package = "mvtnorm")
help("mvrnorm", package = "MASS")

# Here we use the "mvtnorm" version
Gen.Data <- data.frame(rmvnorm(n = 1000, mean=c(10,0), sigma=vcov))
names(Gen.Data) <- c("Y","X")
# Some descriptives
summary(Gen.Data); sd(Gen.Data[,1]); sd(Gen.Data[,2])
# How are they distributed?

#####################
# Monovariate plots #
#####################

# HISTOGRAMS
par(mfrow=c(1,2))
hist(Gen.Data$Y, col = "red", freq = F, main = "Y", xlab = "")
hist(Gen.Data$X, col = "blue", freq = F, main = "X", xlab = "")
# They look pretty similar

# OTHER WAYS TO VISUALIZE MONOVARIATE DATA #
# Density plot
#
# The function density() computes a kerner density estimate for the data that 
# you provide. The KDE is a non-parametric estimation of the probability
# associated to our (continuous) data points. It basically try to infer how
# a variable is distributed in the population given the data that you enter.
# Two elements are important for us: The "Kernel" is a function that
# integrates to 1 and that we associate to the data. The only free parameter, 
# the "Bandwidth", sets the level of "smoothing" that we apply to the function.
# The higher is the level of bandwidth, the more "smooth" will be our density
# function, i.e. the more it will look like a normal density function.

print(density(Gen.Data$Y)) 	# This will call a summary of the estimated values
														# ("x") and the probability associated to them ("y")
# We can plot it
par(mfrow=c(1,1))
plot(density(Gen.Data$Y))
# Let's play with the bandwidth
plot(density(Gen.Data$Y, bw = 1),xlim = c(4,16))
plot(density(Gen.Data$Y, bw = 0.01),xlim = c(4,16))
# ^ here the range of "x" will be more similar to the true range of our
# variable
range(density(Gen.Data$Y, bw = 0.01)$x)
range(Gen.Data$Y)
# while when we increase the bandwidth the range will also increase
range(density(Gen.Data$Y, bw = 1)$x)
# However, the more we smooth, the more we can "make sense" of the distribution
# of our variable.
par(mfrow=c(1,2))
plot(density(Gen.Data$Y, bw = 1),xlim = c(4,16), las = 1,
			main = "Kernel Density of Y", xlab = "Y")
plot(density(Gen.Data$X, bw = 1),xlim = c(-6,6), las = 1,
		 main = "Kernel Density of X", xlab = "X")
# We can make the plots look more fancy
par(mfrow=c(1,2))
# Plot 1
plot(density(Gen.Data$Y, bw = 1),xlim = c(4,16), ylim = c(0,.3), las = 1, 
		 main = "Kernel Density of Y", xlab = "Y", type = "n", # notice type = "n"
		 cex.main = 0.9)
u <- par("usr")		# This saves the coordinates of the plot area
rect(u[1], u[3], u[2], u[4], col = "grey90") # This colors the plot area
abline(v = c(4:16), col = "white")  			# Draws vertical lines
abline(h = seq(from = 0, to = 0.3, by = 0.05), col = "white") # Horizontal lines
lines(density(Gen.Data$Y, bw = 1))   # Re-draws the plot
rug(Gen.Data$Y)  # a rug is often associated to kernel density plots
# Plot 2
plot(density(Gen.Data$X, bw = 1),xlim = c(-6,6), ylim = c(0,.3), las = 1,
		 main = "Kernel Density of X", xlab = "X", type = "n",
		 cex.main = 0.9)
u <- par("usr")
rect(u[1], u[3], u[2], u[4], col = "grey90")
abline(v = c(-6:6), col = "white")
abline(h = seq(from = 0, to = 0.3, by = 0.05), col = "white")
lines(density(Gen.Data$X, bw = 1))
rug(Gen.Data$X)

# We may want to compare our two distributions in a more direct manner

# Boxplots
par(mfrow=c(1,1))
boxplot(Gen.Data$Y,Gen.Data$X, names = c("Y","X"), pch = 20, 
				col = c("grey60","grey70"), boxwex = 0.5, las = 1)
title(main = "Vertical Boxplots of Y and X", cex.main = .9)
# or
boxplot(Gen.Data$Y,Gen.Data$X, names = c("Y","X"), pch = 20, las = 1,
				col = c("grey60","grey70"), boxwex = 0.5, horizontal = T)
title(main = "Horizontal Boxplots of Y and X", cex.main = .9)

# However, boxplots are ugly. 
# A better-looking and relatively easy way to visualize distributions
# (especially when you want to compare two) are the "beanplots"
install.packages("beanplot")
library(beanplot)
beanplot(Gen.Data$Y,Gen.Data$X)
# ^ This looks ugly as well, but we can make it look very nice
beanplot(Gen.Data$Y,Gen.Data$X, what = c(0,1,1,0),   # notice the "what" option
				 col = c("grey60"), border = NA, las = 1, xaxt = "n", beanlinewd = 0.8)
axis(side = 1, at = c(1,2), labels = c("Y","X"))
abline(v=c(1,2), lty = 3)
title(main = "Vertical Beanplots of Y and X", cex.main = .9)

# Again, it can be horizontal
beanplot(Gen.Data$Y,Gen.Data$X, what = c(0,1,1,0), col = c("grey60"),
				 border = NA, las = 1, yaxt = "n", horizontal = T,
				 beanlinewd = 0.8)
axis(side = 2, at = c(1,2), labels = c("Y","X"), las = 1)
abline(h=c(1,2), lty = 3)
title(main = "Horizontal Beanplots of Y and X", cex.main = .9)

# Even better, if we want to compare two distributions
beanplot(Gen.Data$Y, what = c(0,1,1,0), col = c("grey60"), border = NA,
				 las = 1, xaxt = "n", beanlinewd = 0.8, side = "first", 
				 xlim = c(0,2), ylim = c(-5,15))
beanplot(Gen.Data$X, what = c(0,1,1,0), col = c("grey40"), border = NA,
				 las = 1, xaxt = "n", beanlinewd = 0.8, side = "second",
				 xlim = c(0,2), ylim = c(-5,15), add = T)
abline(v=1)
axis(side = 1, at = c(0.5,1.5), labels = c("Y", "X"))
title(main = "Beanplot of Y and X", cex.main = .9)

# You can use beanplots to compare two distributions in a more effective way.
# Think about how it could be used for showing the predicted probabilities of
# a model with an interaction, i.e. half bean on the left is interaction = 0,
# half bean on the right is interaction = 1.

# EXCURSUS: DISCRETE VALUES
# We want to plot a discrete variable, rather than continuous. What can we do?
# First, let's create it
Gen.Data$Z <- cut(Gen.Data$Y, breaks = 5, labels = c(1:5))
summary(Gen.Data$Z) 	# notice that this is equivalent to call
table(Gen.Data$Z)
# Why? The variable that you create with cut() is assumed to be a factor
is.factor(Gen.Data$Z)
# hist() will complain for this
hist(Gen.Data$Z)
# you can force it
hist(as.numeric(Gen.Data$Z))
# but we don't want to..

# You can call a plot for the table() function
plot(table(Gen.Data$Z))
# maybe get the percentages
plot((table(Gen.Data$Z)/length(Gen.Data$Z)), xlab = "Z", ylab = "%", las = 1,
		 col = "brown", lwd = 3)
title(main = "Discrete histogram using table()", cex.main = 0.9)
# To get the nice rectangles it will be pain though.

# The package "arm" has a function for that
install.packages("arm", dependencies = T)
library(arm)
# it will load a number of other packages
help(discrete.histogram, package="arm")
discrete.histogram(Gen.Data$Z, xlab = "Z", bar.width = 0.5, prob.col = "brown",
									 las = 1)
title(main = "Discrete histogram using arm", cex.main = 0.9)
# You will not be able to set many options from here though


############
# Exercise #
############
# Dot charts, pie charts and bar charts
# Plot the variable "Z" in the dataset "Gen.Data" in each of the three styles.
# Try to think how to enter the data in a way that R will actually make the 
# graph. Play around with the settings to make the chart as nice as possible.
# For options, check ?dotchart, ?pie and ?barplot
# Also, with dot charts and bar charts, you may want to sort the categories to
# have the bars on increasing/decreasing size. With pie charts this does not 
# make much sense.



# Dot chart
dotchart(table(Gen.Data$Z)[order(table(Gen.Data$Z))], pch = 20)
# Pie chart
pie(table(Gen.Data$Z))
# Bar chart
barplot(table(Gen.Data$Z)[order(table(Gen.Data$Z))])




# BIVARIATE DATA VISUALIZATION

# When we created "Y" and "X" we wanted them to be correlated at the 50%
# Let's check if it's correct
cor(Gen.Data$Y, Gen.Data$X)		# the cor() function calculates the correlation
															# between two variables. The default is the
															# Pearson's R, but see ?cor for more options
# cor.test() uses a t-test to estimate whether the correlation is statistically
# significantly different from 0
cor.test(Gen.Data$Y, Gen.Data$X)


# Classic bivariate visualization: scatter plot
plot(y = Gen.Data$Y, x = Gen.Data$X, pch = 20, xlab = "X", ylab = "Y",
		 las = 1, main = "Y and X")
# OLS regression
linear.reg <- lm(Gen.Data$Y ~ Gen.Data$X)
summary(linear.reg)
# Use estimates from OLS to draw a straight line on the plot
abline(linear.reg, col = "purple", lty = 4, lwd = 3)
# This looks very 80s

# Before going to improving our scatter plots, let's see another couple of
# bivariate plots that basic R can do

# The Smooth Scatter plots the density of the points by shading different
# regions with different shades, depending on the density of points
smoothScatter(y = Gen.Data$Y, x = Gen.Data$X, ylab = "Y", xlab = "X",
							colramp = colorRampPalette(c("white", "black")), las = 1,
							bandwidth = 0.25) # bandwidth sets the level of smoothing
title(main = "Smooth Scatter of Y and X", cex.main = 0.9)
# It looks fancy, but it's not particularly useful if you don't have many many
# data points

# The basic R has also a function to show a matrix of scatterplots between 
# pairs of variables in your dataset
pairs(Gen.Data, pch = 20)
# Well, in this case it's not really informative. But if you have several 
# continuous variables and you want to plot them in a fast way, there you go.


# Bivariate plots for discrete data
# Example: mosaic plot
# We may want to see the relationship between two factor variables
Gen.Data$W <- cut(Gen.Data$X, breaks = 4, labels = c(1:4))
mosaicplot(Gen.Data$W ~ Gen.Data$Z, xlab = "W", ylab = "Z", main = "", 
					 las = 1, color = T)
title(main = "Mosaic plot of W and Z", cex.main = 0.9)



# However, what most of us want to do is to plot a regression line with a 
# confidence interval around it.
# These type of charts are a clearer way to show your results than numbers and
# stars, and for sure will be strongly appreciated by people who attend your
# presentations and/or read your papers

# So let's start with our previous plot
plot(y = Gen.Data$Y, x = Gen.Data$X, pch = 20, xlab = "X", ylab = "Y",
		 las = 1, main = "Y and X")
# and the regression line
abline(linear.reg)
summary(linear.reg)
# How to put a confidence interval around it?
# First we need to ask the model to return the predicted values
prd <- predict(linear.reg, interval = c("confidence"),level = 0.95)
summary(prd)
# The predictions are saved in a matrix
is.matrix(prd)
is.data.frame(prd)
# but we can append them to the data frame (the order is the same, and in this
# case we don't have missing observations, so it's rather easy)
Gen.Data <- cbind(Gen.Data, prd)
plot(y = Gen.Data$Y, x = Gen.Data$X, pch = 20, xlab = "X", ylab = "Y",
		 las = 1, main = "Y, X, fitted line and 95% C.I.", col = "grey40",
		 cex.main = 0.9)
lines(x = Gen.Data$X[order(Gen.Data$X)], y = Gen.Data$fit[order(Gen.Data$X)],
			lwd = 2)
lines(x = Gen.Data$X[order(Gen.Data$X)], y = Gen.Data$lwr[order(Gen.Data$X)],
			lty = 3)
lines(x = Gen.Data$X[order(Gen.Data$X)], y = Gen.Data$upr[order(Gen.Data$X)],
			lty = 3)
# Notice that we had to sort the data, otherwise the line would have tried 
# to follow the order of the data, and it would have made a mess

# Of course, we can also plot only the fitted values with the c.i.
plot(x = Gen.Data$X[order(Gen.Data$X)], y = Gen.Data$fit[order(Gen.Data$X)],
		 type = "l", ylim = range(min(Gen.Data$lwr)- 1, max(Gen.Data$upr)+1),
		 ylab = "Fitted values", xlab = "X", las = 1)
lines(x = Gen.Data$X[order(Gen.Data$X)], y = Gen.Data$lwr[order(Gen.Data$X)],
			lty = 3)
lines(x = Gen.Data$X[order(Gen.Data$X)], y = Gen.Data$upr[order(Gen.Data$X)],
			lty = 3)
title(main ="Regression Model - Fitted line + 95% C.I.", cex.main = 0.9)
abline(h = 9)


# Plotting the same variables for sub-groups of our sample
# We have seen a couple of sessions ago how to make a histogram of the same
# variable for two groups of the population. Of course, that method extends
# also on scatter plots. 
# However, while that method is still valid, we may want to use a package
# that could make our life way easier with this task.
install.packages("lattice") 	# it should have already been installed by "arm"
library(lattice)

# Let's create a dummy variable to allow us to split the sample in two parts
Gen.Data$dummy <- rep(c(0,1))
table(Gen.Data$dummy)
Gen.Data$dummy[Gen.Data$dummy == 0] <- "Group A"
Gen.Data$dummy[Gen.Data$dummy == 1] <- "Group B"
table(Gen.Data$dummy)
is.character(Gen.Data$dummy)

# Let's use the lattice function xyplot
# see ?xyplot for the multitude of options offered

xyplot(Y ~ X| dummy, data = Gen.Data, pch = 19, col = "black",
			 xlab = "X", ylab = "Y", main = "X and Y")
# You can stack the plots in a different way setting the layout()
xyplot(Y ~ X| dummy, data = Gen.Data, pch = 19, col = "black",
			 xlab = "X", ylab = "Y", main = "X and Y", layout = c(2,1))

# The type() option allows to add many things to the plot, including a 
# regression line
xyplot(Y ~ X| dummy, data = Gen.Data, pch = 19, col = "black",
			 xlab = "X", ylab = "Y", main = "X and Y", 
			 type = c("p", "r"))

# or a smoothing line 
xyplot(Y ~ X| dummy, data = Gen.Data, pch = 19, col = "black",
			 xlab = "X", ylab = "Y", main = "X and Y", 
			 type = c("g", "p", "smooth")) # This will also add a grid


# Two plots on the same panel
xyplot(Y ~ X, groups = dummy, data = Gen.Data, pch = c(15,17), 
			 col = c("red","blue"), xlab = "X", ylab = "Y", 
			 main = "X and Y for groups A and B", type = c("p", "r"),
			 key = list(text = list(unique(Gen.Data$dummy)),  # Legend
			 					 	points = list(pch = c(15,17),
			 						col = c("red","blue"))))


# The difference between specifying a conditioning variable (with "|") or a
# grouping variable (with "groups") is quite important, as it allows to choose
# whether we want to superimpose two (or more) plots or just have them 
# displayed in two (or more) different panels

# Example: density plot of Y for groups "a" and "b"
densityplot(~Y | dummy, data = Gen.Data, col = "black", plot.points = F,
						layout = c(2,1), bw = 0.2)
densityplot(~Y, group = dummy, data = Gen.Data, col = "black", plot.points = F,
						bw = 0.2, lty = c(1,3), key = list(text = list(unique(Gen.Data$dummy)),
						lines = list(lty = c(1,3), col = "black")))




# LEVEL PLOTS
# A very cool finction of lattice are level plots. They can be used to show 
# trivariate relations, as well as to display any kind of correlation repeated
# by group in a very effective way

# For this, we will see the application using some data
setwd("C:\\Users\\Fede\\Desktop\\R course\\Day4")
library(foreign)
EES.iss <- read.dta("EES issues.dta")

# So, we have 5 issue questions, and we want to see how they correlate with 
# respondents' ideological positions in our sample


# They are the first 5 variables in the data set
summary(EES.iss)
# q63, q64, q65, q66, q67
table(EES.iss$q63)
# first, we have 2 categories for missing observations: refused and don't knows
# plus, the variables are factor
is.factor(EES.iss$q63)

# What are the issues about?
# They are 5 likert scales that try to capture the individual position on several
# policy domains. 
# They go from "Completely disagree" (1) to "Completely agree" (5). 
# 3 is the neutral point.
# q63 Income and wealth should be redistributed towards ordinary people
# q64 Schools must teach children to obey authority
# q65 EU treaty changes should be decided by referendum
# q66 A woman should cut down on paid work for her family
# q67 Immigration to [country] should be decreased significantly

# The left-right is numeric
summary(EES.iss$lrsp)
discrete.histogram(EES.iss$lrsp)

# We want to correlate each issue with the left-right, and then put the values
# into a matrix
# but first we need to convert them to numeric, and recode the missing observations
# into NAs
EES.iss$iss1 <- NA
EES.iss$iss2 <- NA
EES.iss$iss3 <- NA
EES.iss$iss4 <- NA
EES.iss$iss5 <- NA
for (i in 1:5) {
	EES.iss[,i + 8]	<- ifelse(as.numeric(EES.iss[,i]) < 6, as.numeric(EES.iss[,i]), NA)
}
table(EES.iss$q63, EES.iss$iss1, useNA = "always")

# Then let's create a matrix called "issue.corr", with a number of columns 
# equivalent to the number of countries, and a number of rows equivalent
# to the number of issues that we want to correlate with the left-right
issue.corr <- matrix(NA,nrow=28,ncol=5)

# Then we make a nested loop (a loop into another loop) to correlate each issue
# with the left-right separately for each country
for (n in 9:13) {     # number of column for our newly-created issues recodes
	for (i in 1:28) { 	# number of country in the "system" variable
		issue.corr[i,(n-8)]<-(cor(EES.iss[EES.iss$system==i,"lrsp"],EES.iss[EES.iss$system==i,n],use="complete.obs"))
	}
}

# Add country names
row.names(issue.corr) <- unique(EES.iss$syslab)
# Add row names to identify the issues
colnames(issue.corr) <- c("Issue1","Issue2","Issue3","Issue4","Issue5")
print(issue.corr)

# Get the minimum and the maximum to determine the cutpoints
min.iss <- min(issue.corr)
max.iss <- max(issue.corr)

levelplot(t(issue.corr), scales=list(tck=0, x=list(rot=90)), 
					col.regions=gray(0:9/9),
					at=c(min.iss,-0.3,-0.2,-0.1,0,0.1,0.2,0.3,0.4,max.iss), 
					main="Issues / left-right correlations", xlab="", ylab=""
)

# You may want to change the cutpoints to try to make better sense of the 
# information shown in the plot - right now it just looks nice, but it's
# not as intuitive as it could be



###################
# EXPORT A FIGURE #
###################
png(filename = "levelplot.png",width = 600, height = 600)  
# ^ sets the parameters for the figure that we want to create, and it saves
# it on the folder that we are working in
levelplot(t(issue.corr), scales=list(tck=0, x=list(rot=90)), 
					col.regions=gray(0:9/9),
					at=c(min.iss,-0.3,-0.2,-0.1,0,0.1,0.2,0.3,0.4,max.iss), 
					main="Issues / left-right correlations", xlab="", ylab=""
)
# ^ makes the plot
dev.off()
# ^ closes the device


# Or 

par(mfrow=c(1,1))
plot(density(Gen.Data$Y, bw = 1),xlim = c(4,16), ylim = c(0,.3), las = 1, 
		 main = "Kernel Density of Y", xlab = "Y", type = "n",
		 cex.main = 0.9)
u <- par("usr")
rect(u[1], u[3], u[2], u[4], col = "grey90")
abline(v = c(4:16), col = "white") 
abline(h = seq(from = 0, to = 0.3, by = 0.05), col = "white")
lines(density(Gen.Data$Y, bw = 1)) 
# ^ make the plot
dev.print(png, file="densityplot.png", width=1024, height=768)
# ^ print what is displayed on the window (the graphics device)

# Check ?png, ?bmp, ?jpeg, ?tiff