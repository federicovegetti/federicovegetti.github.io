#########
# Day 5 #
#########
rm(list=ls())
require(MASS)
require(lattice)
################################
# Let's talk about excercise 1 #
################################

# Some people made some nice 3D plots
ex3.beta.0_small <- NULL
ex3.beta.1_small <- NULL   
ex3.beta.2_small <- NULL
ex3.beta.0_large <- NULL
ex3.beta.1_large <- NULL   
ex3.beta.2_large <- NULL
a <- 0				# set the true intercept at 0
b1 <- 0.5     # set the true slope for b1 at 0.5
b2 <- 0.5     # set the true slope for b2 at 0.5
n <- 1000
vcov_small <- matrix(c(1,0.1,0.1,1), nrow = 2, ncol = 2)
ind.var_small <- data.frame(mvrnorm(n = n, mu = c(0,0), Sigma = vcov_small))
names(ind.var_small) <- c("X1","X2")
sims <- 1000
for (i in 1:sims) {
	Y <- a + b1*ind.var_small$X1 + b2*ind.var_small$X2 + rnorm(n, 0, 1)
	model_small <- lm(Y ~ ind.var_small$X1 + ind.var_small$X2)
	ex3.beta.0_small[i] <- model_small$coef[1]
	ex3.beta.1_small[i] <- model_small$coef[2]
	ex3.beta.2_small[i] <- model_small$coef[3]
}
vcov_large <- matrix(c(1,0.9,0.9,1), nrow = 2, ncol = 2)
ind.var_large <- data.frame(mvrnorm(n = n, mu = c(0,0), Sigma = vcov_large))
names(ind.var_large) <- c("X1","X2")
for (i in 1:sims) {
	Y <- a + b1*ind.var_large$X1 + b2*ind.var_large$X2 + rnorm(n, 0, 1)
	model_large <- lm(Y ~ ind.var_large$X1 + ind.var_large$X2)
	ex3.beta.0_large[i] <- model_large$coef[1]
	ex3.beta.1_large[i] <- model_large$coef[2]
	ex3.beta.2_large[i] <- model_large$coef[3]
}

# Step 1 - add coefficients to the data 
ind.var_large$beta0 <- ex3.beta.0_large
ind.var_large$beta1 <- ex3.beta.1_large
ind.var_large$beta2 <- ex3.beta.2_large
ind.var_small$beta0 <- ex3.beta.0_small
ind.var_small$beta1 <- ex3.beta.1_small
ind.var_small$beta2 <- ex3.beta.2_small
# Here the association data-coefficients is not really meaningful - the fact that
# we simulate 1000 times (and therefore have 1000 coefficients) and our data
# have 1000 observations is a coincidence.
# Coefficients are not associated with data points, like predicted probabilities
# or residuals. They are parameters of the population, like a mean or a standard
# deviation. 
# Nothing bad with putting the coefficients in a data frame together with other
# variables, but this should not convince us that each coefficient corresponds
# to an observation, i.e. we should not plot them together.


# Step 2 - cloud plots
# Beta zeros
cloudbeta0_large <- cloud(beta0 ~ X1*X2, data=ind.var_large, xlim=c(-3.5,3.5), ylim=c(-3.5,3.5), main="beta0", sub="Cor=0.9", zlab=expression(beta[0]))
cloudbeta0_small <- cloud(beta0 ~ X1*X2, data=ind.var_small, xlim=c(-3.5,3.5), ylim=c(-3.5,3.5), main="beta0",sub="Cor=0.1", zlab=expression(beta[0]))
# Beta 1s
cloudbeta1_large <- cloud(beta1 ~ X1*X2, data=ind.var_large, xlim=c(-3.5,3.5), ylim=c(-3.5,3.5), col="red", main="beta1", sub="Cor=0.9", zlab=expression(beta[1]))
cloudbeta1_small <- cloud(beta1 ~ X1*X2, data=ind.var_small, xlim=c(-3.5,3.5), ylim=c(-3.5,3.5), col="red", main="beta1", sub="Cor=0.1", zlab=expression(beta[1]))
# Beta 2s
cloudbeta2_large <- cloud(beta2 ~ X1*X2, data=ind.var_large, xlim=c(-3.5,3.5), ylim=c(-3.5,3.5), col="green", main="beta2", sub="Cor=0.9", zlab=expression(beta[2]))
cloudbeta2_small <- cloud(beta2 ~ X1*X2, data=ind.var_small, xlim=c(-3.5,3.5), ylim=c(-3.5,3.5), col="green", main="beta2",sub="Cor=0.1", zlab=expression(beta[2]))
# Since par(mfrow) doesn't work with lattice graphs, the plots are first put
# into objects and then rightfully called and positioned:
print(cloudbeta0_large, position = c(0.0, 0.66, 0.5, 1), more = TRUE)
print(cloudbeta0_small, position = c(0.5, 0.66, 1, 1), more = TRUE)
print(cloudbeta1_large, position = c(0.0, 0.33, 0.5, 0.66), more = TRUE)
print(cloudbeta1_small, position = c(0.5, 0.33, 1, 0.66), more = TRUE)
print(cloudbeta2_large, position = c(0.0, 0, 0.5, 0.33), more = TRUE)
print(cloudbeta2_small, position = c(0.5, 0, 1, 0.33))
# ^ here I kept only high and low correlations

# What do we learn from this plot?
# What do the three dimensions represent?

##################
# Group of people who probably did the homework together reached the same
# conclusions:

# 1
# "the higher the correlation of X1 and X2 is, the less broad is the 
# distribution of estimated parameters."

# "with a higher correlation of the independent variables X1 and X2,
# the estimated parameters are more centered around one particular value 
# than with smaller correlations."

# 2
# "It is obvious that the higher the correlation the more compressed the 
# graph and the lower the correlation the more randomly distributed."

# 4
# "the smaller the correlation is, the more the points are spread, 
# and the opposite."

# 5
# "the larger the correlation gets, the closer
# the points get together, while the smaller the
# correlation gets, the farer the points are away
# from each other, thus the cloud gets bigger."

# 6
# "The higher the correlation, the more likely we obtain the "compressed" graph.
# The lower correlation coefficient, the more random distribution."

# 7
# "the distributions of the coefficients change from  more sporadic when the
# correlation is very low (0.1) to more dense when it's very high (0.9)"

# 8
# "the higher correlation we have, the more likely we obtain the "compressed" graph.
# "The lower correlation coefficient we have (0.1 for instance), the more random 
# "distribution we have.

# 9
# "The higher the correlation is, the more are the coefficients normally 
# distributed"

# Different analyses, but similar conclusions
# 10
# "We can also see that, generally, estimations of one independant
# variable's impact on the dependant variable are much more
# accurate when there is a high level of correlation between 
# the independant variables"


# So...
# Your conclusions imply that high collinearity between the predictors is a 
# positive thing, because it makes our extimated parameters more precise.
# This is not correct though. It is quite the opposite, as we will see below.


# What is this conclusion based on?
# We have the 3D plot, plus some of you made some histograms:
par(mfrow=c(3,2), mar = c(5, 4, 4, 2) + 0.1)
hist(ex3.beta.0_small, col = "green", freq=FALSE, main="Estimated Intercepts. Cor=0.1", xlab="Estimated Intercepts") 
hist(ex3.beta.0_large, col = "red", freq=FALSE, main="Estimated Intercepts. Cor=0.95", xlab="Estimated Intercepts")
hist(ex3.beta.1_small, col = "green", freq=FALSE, main="Slopes for B1. Cor=0.1", xlab="Estimated Slopes")   	
hist(ex3.beta.1_large, col = "red", freq=FALSE, main="Slopes for B2. Cor=0.95", xlab="Estimated Slopes")
hist(ex3.beta.2_small, col = "green", freq=FALSE, main="Slopes for B2. Cor=0.1", xlab="Estimated Slopes")
hist(ex3.beta.2_large, col = "red", freq=FALSE, main="Slopes for B2. Cor=0.95", xlab="Estimated Slopes")
# What do these histograms tell us?


# Others (actually just 1 person!) got to different conclusions:
# "For lower correlations, the range of the slope values
# is much smaller (however, it is similarly distributed)"
# "the Intercept values on the other hand only seem to differ minimally."
# "It is likely that these differences only stem from the fact that the calculations 
# are made from random values."

# How can we get to these conclusions?

# There are several ways to get there
# First, let's have a look at the standard deviations of our coefficients
sd(ex3.beta.0_small)
sd(ex3.beta.0_large)
# ^ the sd of the intercept doesn't change much
sd(ex3.beta.1_small)
sd(ex3.beta.1_large)
# ^ the sd of the first slope, beta1, is more than doubled
sd(ex3.beta.2_small)
sd(ex3.beta.2_large)
# ^ same here


# Let's make histograms, but letting them overlap
par(mfrow = c(2,2), mar = c(5, 4, 4, 2) + 0.1)
# Beta0 - Intercept
hist(ex3.beta.0_large, col="blue", xlab="Intercept values", main="Comparison of Intercept values")
hist(ex3.beta.0_small, col="red", add=T)
# Beta1 - Slope for X1
hist(ex3.beta.1_large, col="blue", xlab="Slope values for x1", main="Comparison of Slope values for x1")
hist(ex3.beta.1_small, col="red", add=T)
# Beta2 - Slope for X2
hist(ex3.beta.2_large, col="blue", xlab="Slope values for x2", main="Comparison of Slope values for x2")
hist(ex3.beta.2_small, col="red", add=T)

# What is the difference between these histograms and the ones above?

####################
# Other ways to compare the two coefficients in a visual way

# First, let us put our sets of coefficients into a data frame 
# (not together with the data)
small <- data.frame(cbind(ex3.beta.0_small,ex3.beta.1_small,ex3.beta.2_small,rep(1,1000)))
names(small) <- c("b0","b1","b2","cov")
large <- data.frame(cbind(ex3.beta.0_large,ex3.beta.1_large,ex3.beta.2_large,rep(2,1000)))
names(large) <- c("b0","b1","b2","cov")
sims <- data.frame(rbind(small,large))
sims$level[sims$cov==1] <- "Small Collinearity"
sims$level[sims$cov==2] <- "Large Collinearity"

# Same histograms as some of you did, but holding the range of the x and the y
# axes constant 
par(mfrow = c(3,2))
par(mar = c(1,4,4,2))
hist(sims$b0[sims$level=="Small Collinearity"],freq = F,xlim = c(-0.14,0.14),ylim = c(0,15),
		 las=1,col= "green", xlab = "Beta0", main = "Small collinearity")
hist(sims$b0[sims$level=="Large Collinearity"],freq = F,xlim = c(-0.14,0.14),ylim = c(0,15),
		 las=1,col= "red", xlab = "Beta0", main = "Large collinearity")
par(mar = c(3,4,2,2))
hist(sims$b1[sims$level=="Small Collinearity"],freq = F,xlim = c(0.2,0.8),ylim = c(0,13),
		 las=1,col= "green", xlab = "Beta1", main = "")
hist(sims$b1[sims$level=="Large Collinearity"],freq = F,xlim = c(0.2,0.8),ylim = c(0,13),
		 las=1,col= "red", xlab = "Beta1", main = "")
par(mar = c(5,4,0,2))
hist(sims$b2[sims$level=="Small Collinearity"],freq = F,xlim = c(0.2,0.8),ylim = c(0,13),
		 las=1,col= "green", xlab = "Beta2", main = "")
hist(sims$b2[sims$level=="Large Collinearity"],freq = F,xlim = c(0.2,0.8),ylim = c(0,13),
		 las=1,col= "red", xlab = "Beta2", main = "")


# Compare the distributions more directly using the lattice densityplot()
# As you have learned when you made the 3D plots, to put several panels in the
# same pic with lattice is not as straightforward as in the basic R graphics
# package
pl.1 <- densityplot(~b0, group = cov, data = sims, col = "black", plot.points = F,
										lty = c(1,2), key = list(text = list(unique(sims$level)),
										lines = list(lty = c(1,2), col = "black")),xlab = "Intercept")
pl.2 <- densityplot(~b1, group = cov, data = sims, col = "black", plot.points = F,
										lty = c(1,2), key = list(text = list(unique(sims$level)),
										lines = list(lty = c(1,2), col = "black")),xlab = "Slope X1")
pl.3 <- densityplot(~b2, group = cov, data = sims, col = "black", plot.points = F,
										lty = c(1,2), key = list(text = list(unique(sims$level)),
										lines = list(lty = c(1,2), col = "black")),xlab = "Slope X2")

graphics.off()   # This cleans the panel
print(pl.1, position = c(0.0, 0.66, 1, 1), more = TRUE)
print(pl.2, position = c(0.0, 0.33, 1, 0.66), more = TRUE)
print(pl.3, position = c(0.0, 0, 1, 0.33), more = TRUE)


# Here beanplots make sense
require(beanplot)

beanplot(sims$b0[sims$level=="Small Collinearity"], what = c(0,0,0,0), 
				 col = c("grey60"), border = NA, at = 1,
				 xaxt = "n", yaxt = "n", beanlinewd = 0.8, side = "first", 
				 xlim = c(0,6), ylim = c(-0.15,0.8), ylab = "Estimated values")
abline(h=seq(-0.15,0.8,by=0.05),col="grey80")
beanplot(sims$b0[sims$level=="Small Collinearity"], what = c(0,1,1,0), 
				 col = c("grey60"), border = NA, at = 1,
				 beanlinewd = 0.8, side = "first", add = T)
beanplot(sims$b0[sims$level=="Large Collinearity"], what = c(0,1,1,0), 
				 col = c("grey40"), border = NA, at = 1,
				 beanlinewd = 0.8, side = "second", add = T)
beanplot(sims$b1[sims$level=="Small Collinearity"], what = c(0,1,1,0), 
				 col = c("grey60"), border = NA, at = 3,
				 beanlinewd = 0.8, side = "first", add = T)
beanplot(sims$b1[sims$level=="Large Collinearity"], what = c(0,1,1,0), 
				 col = c("grey40"), border = NA, at = 3,
				 beanlinewd = 0.8, side = "second", add = T)
beanplot(sims$b2[sims$level=="Small Collinearity"], what = c(0,1,1,0), 
				 col = c("grey60"), border = NA, at = 5,
				 beanlinewd = 0.8, side = "first", add = T)
beanplot(sims$b2[sims$level=="Large Collinearity"], what = c(0,1,1,0), 
				 col = c("grey40"), border = NA, at = 5,
				 beanlinewd = 0.8, side = "second", add = T)
# And, some aesthetics
abline(v = 0,col="grey80")
abline(v = 1,lty=3)
abline(v = 2,col="grey80")
abline(v = 3,lty=3)
abline(v = 4,col="grey80")
abline(v = 5,lty=3)
abline(v = 6,col="grey80")
axis(side = 1, at = c(1,3,5), labels = c(expression(beta[0]), expression(beta[1]), expression(beta[2])))
axis(side = 2, at = seq(-0.2, 0.8,by=0.1), labels = seq(-0.2, 0.8,by=0.1),las=1,
		 cex.axis = 0.8)
axis(side = 3, at = c(0.5,1.5,2.5,3.5,4.5,5.5), cex.axis = 0.8, tick = F,padj=1,
		 labels = c("cor = 0.1", "cor = 0.9", "cor = 0.1", "cor = 0.9","cor = 0.1", "cor = 0.9"))
mtext(text = "Regression coefficients by two levels of collinearity", side = 3,
			cex =1.3, padj = -3)


# Finally, we can visualize results with dotplots - which is pretty common
# in many published articles
graphics.off()
averages <- c(tapply(sims$b0,INDEX=sims$cov,FUN=mean),
						tapply(sims$b1,INDEX=sims$cov,FUN=mean),
						tapply(sims$b2,INDEX=sims$cov,FUN=mean))
ranges <- c(tapply(sims$b0,INDEX=sims$cov,FUN=sd),
					tapply(sims$b1,INDEX=sims$cov,FUN=sd),
					tapply(sims$b2,INDEX=sims$cov,FUN=sd))
ranges <- ranges*1.96
names(averages) <- c(1,1,2,2,3,3)
names(ranges) <- c(1,1,2,2,3,3)
labels <- c("b0 (cor = 0.1)","b0 (cor = 0.9)","b1 (cor = 0.1)","b1 (cor = 0.9)","b2 (cor = 0.1)","b2 (cor = 0.9)")
dotchart(averages, xlim = c(-0.15,0.75), labels=labels, pch = 20,
				 groups = names(averages), xlab = "Estimated values")
segments(averages-ranges, c(9,10,5,6,1,2), averages+ranges, c(9,10,5,6,1,2))
abline(v=0)
title(main = "Regression coefficients by two levels of collinearity", cex.main = 0.8)

# Both these methods are easy to implement (dot charts easier) and effective,
# although to figure out how the data look like histograms remain the best way.
# Just pay attention to the ranges!

# To sum up, it is actually quite the opposite from what the most of you said:
# The more the two predictors are correlated, the more their estimated effect
# will be imprecise.

# If you think of it, it makes sense in logical terms as well: the more two 
# predictors (Xs) measure the same thing, the harder it will be to assess which
# X is actually producing the effect on Y.

# Check Fox Chapter 13 for a complete explanation of this

# So why the most of you observed the opposite effect?
# My theory: 3D plots.

# 3D plots are a very ineffective way to show data - they are confusing and in 
# most of the cases they cannot tell a story as clear as what we observe with
# "normal" 2D plots.

# In the cloud plot, the cloud of points looks more disperse if we look at it
# from the axes X1 and X2 - indeed, since the level of covariation that we have 
# imposed is smaller, the cloud of points will look larger when we plot the two 
# variables

# We do not need to estimate the coefficients to see this:
vcov_large <- matrix(c(1,0.9,0.9,1), nrow = 2, ncol = 2)
vcov_small <- matrix(c(1,0.1,0.1,1), nrow = 2, ncol = 2)
large_covariance <- data.frame(mvrnorm(n = n, mu = c(0,0), Sigma = vcov_large))
names(large_covariance) <- c("x1","x2")
small_covariance <- data.frame(mvrnorm(n = n, mu = c(0,0), Sigma = vcov_small))
names(small_covariance) <- c("x1","x2")
# Plot
par(mfrow = c(1,2), mar = c(5, 4, 4, 2) + 0.1)
plot(large_covariance$x1,large_covariance$x2,pch = 20,xlab = "x1",ylab = "x2",
		 main = "Large covariance")
plot(small_covariance$x1,small_covariance$x2,pch = 20,xlab = "x1",ylab = "x2",
		 main = "Small covariance")
# What we see here is not the distribution of the estimated parameters - it is the 
# joint distribution of the independent variables




#######################################################
# Exercise - To be finished at home for Thursday 8/11 #
#######################################################

# Use resampling method (Method 2 in the assignment)

# Generate vectors where to put the coefficients
beta_large.0 <- NULL
beta_large.1 <- NULL
beta_large.2 <- NULL
beta_small.0 <- NULL
beta_small.1 <- NULL
beta_small.2 <- NULL

# Generate vectors where to put the standard errors
se_large.0 <- NULL
se_large.1 <- NULL
se_large.2 <- NULL
se_small.0 <- NULL
se_small.1 <- NULL
se_small.2 <- NULL

# Set the true parameters
a <- 0.2
b1 <- 0.5
b2 <- 0.7
n <- 100000

# Set the covariance matrices
vcov_large <- matrix(c(1,0.9,0.9,1), nrow = 2, ncol = 2)
vcov_small <- matrix(c(1,0.1,0.1,1), nrow = 2, ncol = 2)

# Generate our populations
large_covariance <- data.frame(mvrnorm(n = n, mu = c(0,0), Sigma = vcov_large))
names(large_covariance) <- c("x1","x2")
large_covariance$y <- a + b1*large_covariance$x1 + b2*large_covariance$x2 + rnorm(n, 0, 1)
small_covariance <- data.frame(mvrnorm(n = n, mu = c(0,0), Sigma = vcov_small))
names(small_covariance) <- c("x1","x2")
small_covariance$y <- a + b1*small_covariance$x1 + b2*small_covariance$x2 + rnorm(n, 0, 1)


# Estimate the population models to get the "true" parameters
true.model_l <- lm(large_covariance$y ~ large_covariance$x1 + large_covariance$x2)
true.model_s <- lm(small_covariance$y ~ small_covariance$x1 + small_covariance$x2)

# Question 1.
# Ignoring for a minute that a population model should not have standard errors, 
# what is the difference between the standard errors obtained when there is low 
# collinearity (when the covariance between our two predictors is low) and when 
# the collinearity is high?
# Does it remind you of something?


# Set up the simulation
samplesize <- 1000
sims <- 1000

for (i in 1:sims) {
	samp <- sample(n, size = samplesize, replace = F) 
	new_large <- large_covariance[samp,] 							
	new_small <- small_covariance[samp,]
	model_l <- lm(new_large$y ~ new_large$x1 + new_large$x2)
	model_s <- lm(new_small$y ~ new_small$x1 + new_small$x2)
	beta_large.0[i] <- model_l$coef[1] 			
	beta_large.1[i] <- model_l$coef[2]
	beta_large.2[i] <- model_l$coef[3]
	beta_small.0[i] <- model_s$coef[1] 			
	beta_small.1[i] <- model_s$coef[2]
	beta_small.2[i] <- model_s$coef[3]
	# PROBLEM! Add the syntax to extract and save the standard errors 
	# from the models HERE!
}



# Question 2.
# After saving the standard errors (it's not so intuitive), plot both the
# coefficients and the standard errors obtained by resampling from our 
# "large_covariance" and "small_covariance" datasets (no 3D plots!)

# We learned that the more our predictors are correlated, the less the
# estimation of their effect will be precise, i.e. the larger the standard
# deviation of the estimated coefficients. 
# We expect to observe the same here.

# However, what happens to their standard errors?
# What I want to know is whether more collinear predictors produce BIGGER or
# SMALLER standard errors, AND if the set of standard errors produced by 
# resampling is MORE or LESS disperse.

# I want a couple of sentences of explanation of what is going on. 
# No matter if it's formally correct (although some terminology won't hurt),
# I just want you to explain what you see and how you interpret it.
# You can discuss it with others, but I want each of you to use his/her own 
# words!

# NOTE:
# Watch out not to change the sample size - that will influence the standard 
# errors in a way that is not related with your experimental manipulation.




################################
# Let's talk about excercise 2 #
################################
rm(list=ls())
require(MASS)
require(lattice)
# Here more people got the point

# 1. 
# "altough the mean is very close to the true value, in (very) small samples
# the estimated parameters might often be quite far away from the true value 
# of the parameter"

# 2
# "The mean of the intercept did not change significantly. When taking a look at
# the histograms, however, we can observe that the range in the given histograms 
# did change strongly."

# 3
# "small numbers of simulations are very unreliable, even when using
# large sample sizes." 
# "Higher numbers of simulations, however, benefit little from 
# increases in sample size"

# 4
# "the distribution does not seems as much as a normal distribution as in the 
# case of a big sample"
# "compared to the case of a big sample here the parameters estimated from the 
# sample are not as close to the true parameter"

# 5
# "The numbers of the estimated parameters are pretty close to the "true" ones, 
# with the change of the sample size into a more small size (pink graphs) the 
# numbers do not change really, but the graphs become more narrow, to say so 
# not that detailed."

# 6
# "If the whole simulation is run with a much smaller sample size, the mean 
# intercept and slope don't actually change much, even in regard to the true 
# parameters.
# This is not that surprising, considiering that they are means. 
# They may be a bit further away from the true value, but this is down to chance.
# What does change, however, is the standard deviation"
# "These standard deviations are in line with the expecations. If only 50 instead 
# of 1000 samples are drawn from the true population of 100000, they are bound to 
# be "more random" and vary a lot more.
# Consequently, the standard deviation of the mean and slope values calculated from 
# is also greater."

# 7
# "The estimated parameters are very similar to the, say true values,
# yet the estimated parameters do not change significantly when the sample size
# is reduced to 10 from 1000 before. However, due to the smaller sample size
# the graph is less detailed and thus cannot lend too much room for doing
# general interpretations."

# 8 
# "As we can see the mean of the intercept does not change significantly, as the 
# meaning was prescribed at the beginning.
# But with reference to the obtained histograms we can observe that the range in
# the given histograms has changed pronouncedly."

# 9
# "When we have a very small sample size, the estimated parameteres differ a lot
# from the "true" population parameters. There is a bigger difference between
# the estimated parameters and the true ones when we have a very small sample 
# size, in comparison with the case when the sample size is greater."

# 10
# "as we can see the mean of intercept does not change significantly, 
# as the meaning was prescribed at the beginning. 
# But with reference to the obtained histogramms we can obseerve that histogramms
# (namely the range in the given histogramms) has changed pronouncedly."

# 11
# "With a very small sample size, the parameters become more imprecise to the 
# "true" parameters in comparison to the larger sample size"

#
# So, not much to say in this respect.
# We have learned that when we draw very small samples from our population, we
# are more likely to end up with some estimates that have nothing to do with
# the "real" population parameters.

ex2.beta.0 <- NULL
ex2.beta.1 <- NULL
ex2.beta.0_small <- NULL
ex2.beta.1_small <- NULL
a <- 0.2
b <- 0.5
n <- 10000
X <- rnorm(n, 0, 1)
Y <- a + b*X + rnorm(n, 0, 1)
data <- data.frame(cbind(Y,X))
true.model <- lm(data$Y ~ data$X)
true.beta.0 <- true.model$coef[1]
true.beta.1 <- true.model$coef[2]
sims <- 1000

# Another nice and quite self-evident way to show the results
graphics.off()
par(mfrow=c(2,2))
plot(y = data$Y,x = data$X, pch = 20, col = "grey50", xlab = "X", ylab = "Y",
		 main = "Sample size = 1000", las = 1)
for (i in 1:sims) {
	samp <- sample(n, size = 1000, replace = F)
	newdata <- data[samp,]
	model <- lm(newdata$Y ~ newdata$X)
	ex2.beta.0[i] <- model$coef[1]
	ex2.beta.1[i] <- model$coef[2]
	abline(model)
}
plot(y = data$Y,x = data$X, pch = 20, col = "grey50", xlab = "X", ylab = "Y",
		 main = "Sample size = 100", las = 1)
for (i in 1:sims) {
	samp <- sample(n, size = 100, replace = F)
	newdata <- data[samp,]
	model <- lm(newdata$Y ~ newdata$X)
	ex2.beta.0[i] <- model$coef[1]
	ex2.beta.1[i] <- model$coef[2]
	abline(model)
}
plot(y = data$Y,x = data$X, pch = 20, col = "grey50", xlab = "X", ylab = "Y",
		 main = "Sample size = 50", las = 1)
for (i in 1:sims) {
	samp <- sample(n, size = 50, replace = F)
	newdata <- data[samp,]
	model <- lm(newdata$Y ~ newdata$X)
	ex2.beta.0[i] <- model$coef[1]
	ex2.beta.1[i] <- model$coef[2]
	abline(model)
}
plot(y = data$Y,x = data$X, pch = 20, col = "grey50", xlab = "X", ylab = "Y",
		 main = "Sample size = 10", las = 1)
for (i in 1:sims) {
	samp <- sample(n, size = 10, replace = F)
	newdata <- data[samp,]   	
	model <- lm(newdata$Y ~ newdata$X)
	ex2.beta.0[i] <- model$coef[1]
	ex2.beta.1[i] <- model$coef[2]
	abline(model)
}



########################
# The comfort of Zelig #
########################
# Zelig is a R package that makes our life easier in many respects. It does 
# nothing that other packages don't do, but it allows us to present our
# results in a very intuitive way.

#install.packages("Zelig", dependencies = T)
# ^ this will take a while
require(Zelig)
# let's load some data for this
require(foreign)
setwd("C:\\Users\\Fede\\Desktop\\R course\\Day5")
nes <- read.dta("nes.dta")
summary(nes)
View(nes)

# Our dependent variable(s):
# dlikes: the affect towards the Democrat presidential candidate
# rlikes: the affect towards the Republican presidential candidate
# They both go from -5 (max negative affect) to +5 (max positive affect)

# Our independent variables:
# age (linear)
# female (dummy)
# income (ordinal)
# black (dummy)
# educ1 (education, ordinal)
# possibly, and interaction between "educ1" and "black"

# first, let's set a couple of variables as numeric
nes$inc <- as.numeric(nes$income)
nes$edu <- as.numeric(nes$educ1)

model <- zelig(dlikes ~ age + female + inc + black*edu, data = nes, model = "ls")
summary(model)

# We want to see:
# 1. The difference between men and women in the evaluation of the democratic
# (republican) presidential candidate
# 2. The different effect of education among black and non-black voters

# 1
# Set the values as we want them using setx()

x.woman <- setx(model,female = 1,	data = nes)
x.man <- setx(model,female = 0,	data = nes)
sim.1 <- sim(model,x=x.man,x1=x.woman)
summary(sim.1)
plot(sim.1)

# which is the same as
par(mfrow=c(2,1))
hist(sim.1$qi$ev, col = "yellow", freq = F,las = 1)
hist(sim.1$qi$fd, col = "yellow", freq = F,las = 1)
# ^ here "qi" means "quantities of interest" and "fd" means "first differences"

# 2
# For simulating the second set of differences, let's first put into an object
# the full range of our "edu" variable
edu.range <- seq(min(nes$edu, na.rm = T),max(nes$edu, na.rm = T),length.out = 100)
black.edu <- setx(model, edu = edu.range, black = 1)
nobl.edu <- setx(model, edu = edu.range, black = 0)
sim.2 <- sim(model, x = nobl.edu, x1 = black.edu)
summary(sim.2)
par(mfrow=c(1,1))
plot.ci(sim.2)

############
# Exercise #
############
# model2 (below) is very similar to our previous model, but this time interaction is 
# between gender (female) and income
model2 <- zelig(dlikes ~ age + female*inc + black + edu, data = nes, model = "ls")
model3 <- zelig(rlikes ~ age + female*inc + black + edu, data = nes, model = "ls")
summary(model2)
summary(model3)

# We want to show whether and how the effect of income on the sympathy scale for the
# democratic party is different between men and women.
# We want to show a similar plot to the one we did for "black" and "edu".













inc.range <- seq(min(nes$inc, na.rm = T),max(nes$inc, na.rm = T),length.out = 100)
woman.edu.d <- setx(model2, inc = inc.range, female = 1)
man.edu.d <- setx(model2, inc = inc.range, female = 0)
sim.3.d <- sim(model2, x = man.edu.d, x1 = woman.edu.d)
woman.edu.r <- setx(model3, inc = inc.range, female = 1)
man.edu.r <- setx(model3, inc = inc.range, female = 0)
sim.3.r <- sim(model3, x = man.edu.r, x1 = woman.edu.r)
summary(sim.3.d)
summary(sim.3.r)
par(mfrow=c(2,1))
plot.ci(sim.3.d)
plot.ci(sim.3.r)