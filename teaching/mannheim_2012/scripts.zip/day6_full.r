#########
# Day 6 #
#########
rm(list=ls())

#################################
# A fast look at the assignment #
#################################
require(MASS)

# Generate vectors where to put the coefficients
beta_large.0 <- NULL
beta_large.1 <- NULL
beta_large.2 <- NULL
beta_small.0 <- NULL
beta_small.1 <- NULL
beta_small.2 <- NULL

# Generate vectors where to put the standard errors
se_large.0 <- NULL
se_large.1 <- NULL
se_large.2 <- NULL
se_small.0 <- NULL
se_small.1 <- NULL
se_small.2 <- NULL

# Set the true parameters
a <- 0.2
b1 <- 0.5
b2 <- 0.7
n <- 100000

# Set the covariance matrices
vcov_large <- matrix(c(1,0.9,0.9,1), nrow = 2, ncol = 2)
vcov_small <- matrix(c(1,0.1,0.1,1), nrow = 2, ncol = 2)
# covariance between X1 and X2

# Generate our populations
large_covariance <- data.frame(mvrnorm(n = n, mu = c(0,0), Sigma = vcov_large))
names(large_covariance) <- c("x1","x2")
large_covariance$y <- a + b1*large_covariance$x1 + b2*large_covariance$x2 + rnorm(n, 0, 1)
small_covariance <- data.frame(mvrnorm(n = n, mu = c(0,0), Sigma = vcov_small))
names(small_covariance) <- c("x1","x2")
small_covariance$y <- a + b1*small_covariance$x1 + b2*small_covariance$x2 + rnorm(n, 0, 1)


# Estimate the population models to get the "true" parameters
true.model_l <- lm(large_covariance$y ~ large_covariance$x1 + large_covariance$x2)
true.model_s <- lm(small_covariance$y ~ small_covariance$x1 + small_covariance$x2)

summary(true.model_l)
summary(true.model_s)


# Set up the simulation
samplesize <- 1000
sims <- 1000

for (i in 1:sims) {
	samp <- sample(n, size = samplesize, replace = F) 
	new_large <- large_covariance[samp,] 							
	new_small <- small_covariance[samp,]
	model_l <- lm(new_large$y ~ new_large$x1 + new_large$x2)
	model_s <- lm(new_small$y ~ new_small$x1 + new_small$x2)
	beta_large.0[i] <- model_l$coef[1] 			
	beta_large.1[i] <- model_l$coef[2]
	beta_large.2[i] <- model_l$coef[3]
	beta_small.0[i] <- model_s$coef[1] 			
	beta_small.1[i] <- model_s$coef[2]
	beta_small.2[i] <- model_s$coef[3]
	se_large.0[i] <- coef(summary(model_l))[1,2]
	se_large.1[i] <- coef(summary(model_l))[2,2]
	se_large.2[i] <- coef(summary(model_l))[3,2]
	se_small.0[i] <- coef(summary(model_s))[1,2]
	se_small.1[i] <- coef(summary(model_s))[2,2]
	se_small.2[i] <- coef(summary(model_s))[3,2]
	# OR
	# se_large.0[i] <- sqrt(diag(vcov(model_l)))[1]
	# se_large.1[i] <- sqrt(diag(vcov(model_l)))[2]
	# se_large.2[i] <- sqrt(diag(vcov(model_l)))[3]
	# se_small.0[i] <- sqrt(diag(vcov(model_s)))[1]
	# se_small.1[i] <- sqrt(diag(vcov(model_s)))[2]
	# se_small.2[i] <- sqrt(diag(vcov(model_s)))[3]
}

# Let's make histograms out of them
par(mfrow=c(2,2))
hist(beta_large.0, col="blue", freq=F, xlab="Intercept values", main="Comparison of Intercept values")
hist(beta_small.0, add=T, col="red", freq=F)

hist(beta_large.1, col="blue", freq=F, xlab="Slope values for x1", main="Comparison of Slope values for x1", ylim=c(0,12))
hist(beta_small.1, add=T, col="red", freq=F)

hist(beta_large.2, col="blue", freq=F, xlab="Slope values for x2", main="Comparison of Slope values for x2", ylim=c(0,12))
hist(beta_small.2, add=T, col="red", freq=F)
# Advice for a legend (works for this case, still needs some improvisation)
plot.new()
legend("topleft", c("High collinearity", "Low collinearity"), fill=c("blue", "red"),bty="n", 
			 inset=c(0,-0.2)) # with "inset" you can set the distances from the margins


par(mfrow=c(2,2))
hist(se_large.0, col="blue", freq=F, xlab="Standard errors - beta 0", main="Comparison of standard errors - beta 0")
hist(se_small.0, add=T, col="red")

hist(se_small.1, col="red", xlim=c(0.025, 0.08), freq=F, xlab="Standard errors - beta 1", main="Comparison of standard errors - beta 1")
hist(se_large.1, add=T, col="blue")

hist(se_small.2, col="red", xlim=c(0.025, 0.08), freq=F, xlab="Standard errors - beta 2", main="Comparison of standard errors - beta 2")
hist(se_large.2, add=T, col="blue")

plot.new()
legend("topleft", c("High collinearity", "Low collinearity"),bty="n", 
			 inset=c(0,-0.2), lty=c("solid", "solid"), col=c("blue", "red"),
			 lwd = 3) # the legend with the line looks better

# Other nice plotting ideas using the rgb function
par(mfrow=c(1,1))
hist(se_large.0, col=rgb(0,0,1,1/2), xlim=c(0.027,0.037), main="Intercept Standard errors", xlab="Standard Error"
		 ,freq=F, ylim = c(0,550))
hist(se_small.0, col=rgb(1,0,0,1/2), , 
		 freq=F, add=T)
legend("topright",
			 ,c("High covariance","Low covariance")
			 ,pch=15
			 ,col=c(rgb(0,0,1,1/2),rgb(1,0,0,1/2))
			 ,cex=.8
)

par(mfrow=c(1,1))
hist(se_small.1, col=rgb(0,0,1,1/2), xlim=c(0.02,0.09), main="X1 Standard errors", xlab="Standard Error", breaks=20,
		 freq = F)
hist(se_large.1, col=rgb(1,0,0,1/2), breaks=20, 
		 freq = F, add=T)
legend("topright",
			 ,c("High covariance","Low covariance")
			 ,pch=15
			 ,col=c(rgb(0,0,1,1/2),rgb(1,0,0,1/2))
			 ,cex=.8
)

par(mfrow=c(1,1))
hist(se_small.2, col=rgb(0,0,1,1/4), xlim=c(0.02,0.09), main="X2 Standard errors", xlab="Standard Error", breaks=20,
		 freq = F)
hist(se_large.2, col=rgb(1,0,0,1/4), breaks=20, 
		 freq = F, add=T)
legend("topright",
			 ,c("High covariance","Low covariance")
			 ,pch=15
			 ,col=c(rgb(0,0,1,1/4),rgb(1,0,0,1/4))
			 ,cex=.8
)     

# A few tips for comparing histograms:
# 1. Type freq=F, so you'll have the densities, which are more directly 
# comparable than counts.
# 2. You will always need to introduce the ranges of the axes manually, at
# least for what concerns the y-axis in histograms. So when you use add = T,
# always pay attention to set in the first plot a range that can contain both
# histograms.
# 3. When you specify add = T you don't need to set the range and the labels
# again in the second plot.
# However, well done.

###################################################
# Some more on Linear Models and problematic data #
###################################################
rm(list=ls())
require(MASS)

# We have learned quite well that multicollinearity makes our estimated 
# coefficients less certain, and also the estimated error less precise.
# More importantly, we have learned how important an appropriate data 
# visualization can be for understanding what is going on with the often
# huge sets of numbers that consist in our data.

# In this part we will have a (fast) look at other potential problems in
# estimating regression models with our data, and the solution(s) that R
# offers us to solve them.

# Sometimes, our dependent variable presents some "outliers", i.e. some 
# idiosyncratic sources of variation that do not come from the data generating
# process that we want to model - in fact, outliers often come from particular
# events that are not systematically related to the mechanisms that regulate
# the phenomena that we hypothesize under "normal" conditions.

# We can find some examples in political science. Let us suppose that we want
# to explain the level of democratization of a country (several indexes of 
# democracy that allow us to model it as a continuous variable are available)
# with its economic wealth, using some common indicators like the GDP per 
# capita.
# The idea is that more wealthy countries are characterized by high levels
# of literacy, schooling and media access, and promote intermediary 
# organizations such as labor unions and voluntary organizations, promoting
# the values of legitimacy and social tolerance.
# Although we may expect economic wealth to have a positive effect on the 
# level of democracy, we have to take into account that many big oil 
# producers, such e.g. the Arab Emirates, have a very high GDP per capita
# but score very low in the most common indexes of democracy.
# The fact that they produce oil increases their wealth to a great extent, 
# but it does it in a way that is different from the mechanism that we have
# hypothesized (that, at the end of the day, refers to an expanding 
# middle-class).

# Substantively speaking, outliers represent data points that are generated by
# a DGP that is different from the systematic one that we seek ot explain.
# Statistically speaking, outliers violate the normal i.i.d. assumtpion of 
# the residual error (i.e. the residuals are independently and identically
# distributed). 
# This implies that our regression line, fitted using the OLS method, tends
# to pass closer to the outlying observations, giving us wrong estimates of
# the coefficients

# It sounds complicated, but it's not. We can figure this out via simulation.

a <- 0
b <- 0.5
n <- 1000
X <- rnorm(n, 0, 1)
Y <- a + b*X + rnorm(n, 0, 1)
data.1 <- data.frame(cbind(Y,X))
plot(data.1$Y ~ data.1$X, pch = 20, xlab = "X", ylab = "Y")
abline(lm(data.1$Y ~ data.1$X), col = "blue", lwd = 2)
model.1 <- lm(data.1$Y ~ data.1$X)
summary(model.1)
# That's our DGP. Now we want to add some observations that come from a different
# causal process.
# Two things are expected to influence our estimates: how many deviant cases we
# have and how deviant they are. Given that a big proportion of outliers compared
# to our data may indicate that they are not outliers (and in this case we would
# have to rethink the way in which we expect the data generating process to be)
# we will concentrate now on a few cases (around the 5% of our sample) that deviate
# a lot from the average

# We select them randomaly:
deviant.cases <- sample(1:n, 50, replace = F)
# and we assign them some extreme deviating values
# we first have a look at how our Y is distributed
hist(data.1$Y, col="green")
# The one below is just a possibility (of rather extreme outliers)
deviant.y <- sample(seq(15,20,length.out = 1000), length(deviant.cases), replace = T)
data.2 <- data.1
data.2[deviant.cases,"Y"] <- deviant.y
data.2$dum <- 0
data.2[deviant.cases,"dum"] <- 1
table(data.2$dum)
hist(data.2$Y, col="green")

plot(data.2$Y ~ data.2$X, pch = 20, xlab = "X", ylab = "Y with outliers")
abline(lm(data.2$Y ~ data.2$X), col = "blue", lwd = 2)
abline(lm(data.1$Y ~ data.1$X), col = "red", lwd = 2)

model.2 <- lm(data.2$Y ~ data.2$X)
summary(model.1)
summary(model.2)

model.2.dummy <- lm(data.2$Y ~ data.2$X*data.2$dum)
summary(model.2.dummy)
coef(model.1)
coef(model.2)
co <- coef(model.2.dummy)

plot(data.2$Y ~ data.2$X, pch = 20, xlab = "X", ylab = "Y with outliers")
abline(a= co[1], b = co[2], col = "red", lwd = 3)
abline(a = co[1] + co[3], b = co[2] + co[4], col = "green", lwd = 3)


# What is the difference between the results that we obtain with the 2 models?

#############
# Excercise #
#############
# What happens when the deviant cases occur only when X is bigger than 0, i.e.
# when they are not really random, but rather correlated with one of our variables?
# Try to replicate what's done above substituting with deviant cases only the
# observations where X is positive.
# Then plot them again, and run an OLS model as above.
# How do the coefficients change? How do the standard errors change?

# You can also play a bit more with the simulation and, for instance:
# 1. Increase the number of outliers
# 2. Increase the deviance of the outliers
# 3. Set other conditions for the sampling







row.names(data.1)
pos.x <- as.numeric(row.names(data.1[data.1$X>0,]))
deviant.cases <- sample(pos.x, 50, replace = F)
deviant.y <- sample(seq(15,20,length.out = 1000), length(deviant.cases), replace = T)

data.3 <- data.1
data.3[deviant.cases,"Y"] <- deviant.y

plot(data.3$Y ~ data.3$X, pch = 20, xlab = "X", ylab = "Y with outliers")
abline(lm(data.3$Y ~ data.3$X), col = "blue", lwd = 2)
abline(lm(data.1$Y ~ data.1$X), col = "red", lwd = 2)

model.3 <- lm(data.3$Y ~ data.3$X)
summary(model.1)
summary(model.3)

##############################################################
# Some solutions: Robust Regression and Resistant Regression #
##############################################################
# The Robust and the Resistant regressions are two estimation procedures offered
# by the "robustbase" and the "MASS" packages that can help in these cases

# Let us simulate again, this time simulating two different processes
# which share the same logic
vcov <- matrix(c(1,-0.2,-0.2,1), nrow = 2, ncol = 2)
n <- 1000
data.4 <- data.frame(cbind(1:n,(mvrnorm(n = n, mu = c(0,0), Sigma = vcov))))
names(data.4) <- c("ID", "Y", "X")
model.ok <- lm(data.4$Y ~ data.4$X)
summary(model.ok)
plot(data.4$Y ~ data.4$X, pch = 20, xlab = "X", ylab = "Y")
abline(lm(data.4$Y ~ data.4$X),col = "blue",lwd = 2)
# It looks as it should. Now let's randomly select some deviant cases
deviant.cases <- sample(1:n,50,replace = F)
# Now we substitute some cases with deviant observations. We generally define
# outliers those observations which are from about 3 standard deviations away
# from the average. Here we set it for both Y and X
deviant.yx <- mvrnorm(n = length(deviant.cases), mu = c(3,3), Sigma = vcov)
data.4.new <- data.4
data.4.new[deviant.cases,c("Y","X")] <- deviant.yx
model.bias <- lm(data.4.new$Y ~ data.4.new$X)
summary(model.bias)
summary(model.ok)
# It looks like the coefficient of X is reversed now
plot(data.4.new$Y ~ data.4.new$X, pch = 20, xlab = "X", ylab = "Y")
abline(lm(data.4$Y ~ data.4$X),col = "blue",lwd = 2)
abline(lm(data.4.new$Y ~ data.4.new$X),col = "red",lwd = 2)

# So we have a bunch of observations (not so many, actually) that deviate from
# our distributions. We somehow see it plotting the variables alone
par(mfrow = c(2,2))
r.y <- range(data.4.new$Y)+c(-0.5,0.5)
r.x <-range(data.4.new$X)+c(-0.5,0.5)
hist(data.4$Y,col = "blue",freq = F, xlim = r.y, ylim = c(0,0.4),
		 main = "Y without outliers", xlab = "")
hist(data.4.new$Y,col = "red",freq = F, xlim = r.y, ylim = c(0,0.4),
		 main = "Y with outliers", xlab = "")
hist(data.4$X,col = "blue",freq = F, xlim = r.x, ylim = c(0,0.4),
		 main = "X without outliers", xlab = "")
hist(data.4.new$X,col = "red",freq = F, xlim = r.x, ylim = c(0,0.4),
		 main = "X with outliers", xlab = "")

# The robust regression is based on an estimation procedure where the residuals 
# are weighted, with a smaller weight given to more deviant observations, and 
# bigger weight given to less deviant observations. Since the y-hat (i.e. the
# expected value of Y for every point of X) also changes position as the residuals
# are weighted differently, the function proceeds iterating until it finds a 
# convergence (i.e. optimal values for the weights and the coefficients)
# A function called rlm() is provided in the "MASS" package
model.robust <- rlm(data.4.new$Y ~ data.4.new$X)
summary(model.robust)
# let's compare this with the "ok" model
summary(model.ok)
# kind of..
# However, the best function for performing robust regression in case of outliers
# is the lmrob() function in the "robustbase" package
#install.packages("robustbase")
require(robustbase)
model.robust.base <- lmrob(data.4.new$Y ~ data.4.new$X)
coef(model.ok)
coef(model.bias)
coef(model.robust)
coef(model.robust.base)
summary(model.robust.base)

# Let's compare them directly

graphics.off()
par(mfrow = c(1,1),mar=c(5.1, 4.1, 4.1, 4.1))
plot(data.4.new$Y ~ data.4.new$X, pch = 20, xlab = "X", ylab = "Y")
abline(lm(data.4$Y ~ data.4$X),col = "blue",lwd = 2)
abline(lm(data.4.new$Y ~ data.4.new$X),col = "red",lwd = 2)
abline(rlm(data.4.new$Y ~ data.4.new$X), col = "green", lwd = 2)
abline(lmrob(data.4.new$Y ~ data.4.new$X), col = "maroon", lwd = 2)
legend("right",c("No outliers","No robust","rlm()","lmrob()"),pch=20,
			 col=c("blue","red","green","maroon"),xpd=T, inset=c(-1.5,0),bty="n")
title(main="Performance of Robust Regression with Outliers")

# Resistant regression works in a slightly different way. Here we can choose either
# to rely on a least median squares (LMS) type of estimation (as we know that the 
# median is in general less sensitive to outliers than the mean) or a least trimmed
# squares estimator (LTS). The latter estimates our model "trimming" our data,
# that is, chopping off the observations that are out of a range defined by us with
# the option "quantile"
model.lms <- lqs(data.4.new$Y ~ data.4.new$X, method = "lms")
coef(model.lms)

model.lts <- lqs(data.4.new$Y ~ data.4.new$X, method = "lts",quantile=50)
coef(model.lts)

par(mfrow = c(1,1),mar=c(5.1, 4.1, 4.1, 4.1))
plot(data.4.new$Y ~ data.4.new$X, pch = 20, xlab = "X", ylab = "Y")
abline(lqs(data.4.new$Y ~ data.4.new$X, method = "lms"), col = "green", lwd = 2)
abline(lqs(data.4.new$Y ~ data.4.new$X, method = "lts",quantile=30), col = "grey30", lwd = 2)
abline(lqs(data.4.new$Y ~ data.4.new$X, method = "lts",quantile=60), col = "grey60", lwd = 2)
abline(lqs(data.4.new$Y ~ data.4.new$X, method = "lts",quantile=90), col = "grey90", lwd = 2)
abline(lm(data.4$Y ~ data.4$X),col = "blue",lwd = 2)
abline(lm(data.4.new$Y ~ data.4.new$X),col = "red",lwd = 2)
legend("right",c("LMS","LTS (q=30)","LTS (q=60)","LTS (q=90)", "No outliers", "No robust"),pch=20,
			 col=c("green","grey30","grey60","grey90","blue","red"),xpd=T, inset=c(-0.6,0),bty="n")
title(main="Performance of Resistant Regression with Outliers")

# However, resistant regression is not very commonly used. What you should do in 
# these cases can be discussed.
# Anyway, lot of useful information about robust regression (as for many other 
# stats issues) can be found on Wikipedia: 
# http://en.wikipedia.org/wiki/Robust_regression





#############
# Excercise #
#############
# Let's now use only the lmrob() robust model. 
summary(lmrob(data.4.new$Y ~ data.4.new$X))
# Try to increase the deviance of the outliers from the syntax used above, and see
# how the robust estimator performs.





##################
# Some basic GLM #
##################
# Generalized Linear Models are a class of models thought to extend the linear 
# modeling framework to several types of data generating processes.
# It can be used to fit linear regression models, logistic regression models (used 
# when the dependent variable is dichotomous), poisson regression models (used when
# the dependent variable is a count) and many others.
# Like in linear models, GLMs have a response variable Y and a set of predictors
# X1... Xn. 
# The difference is that GLMs introduce a quantity called "linear predictor".
# In GLMs, the value of our response variable is a function of the linear predictor. 
# While the relationship between the Y and the Xs does not have to be linear, the 
# relation between the Xs and the linear predictor has to be linear.
# The only way in which the Xs influence the Y is through the linear predictor.

#----------------------------------------------------------------------------#
# Let's make an example using the logistic function -- the one most commonly #
# assumed when we do regression with a dichotomous dependent variable.			 #
#----------------------------------------------------------------------------#

# Our response variable is "vegetarianism", i.e. the fact that a person is
# vegetarian. Let's forget for a second about vegans, pescatarians, people who
# only eat chicken and roadkill-vegetarians (a peculiar movement) - in our world
# people are either vegetarian or not.
# Our linear predictor is a latent trait - the sympathy towards animals.
# When it takes value 0, people are indifferent - they don't have either positive
# nor negative feelings towards animals.
# When it takes a positive value, people have positive feelings towards animals,
# and when it takes a negative value, they have a negative feeling.
# People can be extremely positive or extremely negative towards animals, but we
# don't care. We only assume that people with a positive value have a probability
# bigger than a coin flip to become vegetarian, and that people with a negative
# value have a lower probability.
# Our X is the level of empathy, i.e. the emotional capacity to recognize feelings
# that are being experienced by other people. Let's assume it's effect is positive
# and rather strong (beta = 0.8) and that the trait it measured on a 5-point
# scale
# We make it a bit more variant for giving a better idea
rm(list=ls())
require(MASS)
vcov <- matrix(c(2,0.8,0.8,2), nrow = 2, ncol = 2)
n <- 1000
data <- data.frame(mvrnorm(n, mu = c(0,0), Sigma = vcov))
names(data) <- c("Y","X")

# We convert X into the 5-point scale
data$X <- cut(data$X,breaks = 5, labels = F)
data$X <- data$X - 3      # let's center it
# We define the probability to be vegetarian as a function of our latent trait
# The function is the logistic function, and it is the inverse of the function
# that it is normally applied to obtain predicted probabilities from the 
# coefficients of a logit model (which, in fact, is called "inverse logit").
# It is also the function that the GLM estimator uses as a link function between
# your response variable (observed) and the linear predictor (unobserved)
data$prob <- 1/(1 + exp(-data$Y))
# ^ You can find this formula here: http://en.wikipedia.org/wiki/Logistic_function

# So how do they relate?
graphics.off()
plot(y=data$prob,x=data$Y,pch = 20, xlab = "Linear Predictor", ylab = "Probability",
		 las = 1)
abline(h=0.5)
abline(v=0)

# Now, the next step would be to assign each variable who has probability bigger 
# than 0.5 a response of 1 and each variable who has it lower than 0.5 a response
# of 0.
# But we like it random, so we will simulate it with rbinom()
data$response <- rbinom(n = n,size = 1, prob=data$prob)

# How does it relate with the probability?
plot(y=jitter(data$response,amount = 0.05),x=data$prob, pch= 20, xlab = "Probability", ylab = "Response",
		 las = 1)
abline(v=0.5)

# How does it relate with the linear predictor?
plot(y=jitter(data$response,amount = 0.05),x=data$Y, pch= 20, xlab = "Linear Predictor", ylab = "Response",
		 las = 1)
abline(v=0)

# Notice that the linear predictor does not have a substantive meaning - like, in
# our case, "sympathy towards animals". The linear predictor is necessary in GLM
# to link our independent variables with the dependent variable, but it does not 
# tell anything itself.
# We will have a better hunch of this as we get predicted probabilities.

# Let's run a linear model on the linear predictor
linear.1 <- glm(data$Y ~ data$X, family = gaussian(link = "identity"))
summary(linear.1)
# First, notice the "family" and "link" specifications.
# Second, notice that this model will return the same results as the OLS:
linear.2 <- lm(data$Y ~ data$X)
summary(linear.2)

# Normally we don't have information about the linear predictor, but we only have
# the "response" variable, i.e. our set of 0s and 1s.
# Therefore, we need to specify a different "family" (i.e. how we assume the
# dependent variable to be distributed) and a different "link" function (i.e. how
# we want the values in the linear predictor to be transformed to become probabilieies).

# We know the family (what kind of distribution generated our data?) and we know
# the link function - indeed we have used it ourselves to generate the probabilities.

logit.1 <- glm(data$response ~ data$X, family = binomial(link = "logit"))
summary(logit.1)

# Let us compare the two sets of coefficients:
coef(linear.1)
coef(logit.1)

# However, we have an interpretation problem here: while the effect of X on the 
# linear predictor is directly intepretable (i.e. how much our Y changes as we 
# increase X of 1 point), what do the coefficients of the logit model mean?



