#########
# Day 7 #
#########
rm(list=ls())
###################################################################
# Categorical dependent variables - because we are not economists #
###################################################################
# Many many times, what we want to estimate is the probability of a 
# certain outcome. 
# E.g. Individual probability to vote for the government instead of 
# for the opposition; the probability that a certain bill is passed; 
# the probability that a press release is reported in a certain 
# newspaper, and so on.
# The outcome can be multiple (e.g. when there are more than 2 choices),
# ordinal (when the categories are ordered, e.g. to be against, neutral 
# or in favor of a certain law), or it can consist into a count (i.e. the
# number of days passed before something happens).
#
# Here we will take care only about dichotomous outcomes, i.e. an event
# that can only happen (1) or not happen (0).
# We will do so because:
# 1. It's complicated enough.
# 2. When you get the logic of this, the rest is just a matter of generalization.
# 3. Dichotomous outcomes are more common.
#
# We will start with an example about American football.
# We have a dataset with several statistics, including whether a player 
# attempted a "field goal" (i.e. kicking the ball through the goal, like
# we know from European football) with or without success.
# We presume that the chance of succeeding or failing varies depending
# on the distance from where the kick is made: goals attempted closer
# to the end zone are more likely to succeed.
setwd("C:\\Users\\Fede\\Desktop\\R course\\Day7")
load("field.goals.rda")
View(field.goals)
# We care about the variables "play.type" and "yards"
graphics.off()
plot(table(field.goals$play.type)/length(field.goals$play.type),
		 ylab = "Percent of the total", xlab = "Outcome", lwd = 5, col = "blue",
		 main = "Outcomes of attempted goals", yaxt = "n")
axis(2,at=c(0,0.2,0.4,0.6,0.8),labels = c("0%","20%","40%","60%","80%"),las=1)
#
hist(field.goals$yards, col = "green", breaks = 20, freq = F, 
		 xlab = "Distance in Yards", cex.main = 0.9, las = 1,
		 main = "Distance from where a goal is attempted")

field.goals <- transform(field.goals,good=ifelse(play.type=="FG good",1,0))
# ^ This is a fancy way to create a new variable
table(field.goals$good)

# Our data now present a dichotomous outcome:
# 1 = Good
# 0 = Bad
# How to deal with this?

plot(y=jitter(field.goals$good,amount=0.05),x=field.goals$yards,pch=20,
		 las =1,xlab = "Distance (Yards)", ylab = "Outcome")
# We can predict the probability of a good outcome as a linear function
# of the distance. This approach is called "linear probability", and it's 
# used more often than you would expect
linear <- lm(good ~ yards, data = field.goals)
summary(linear)
abline(linear)
# ^ what is wrong with these results?
# How do you interpret the coefficients?


# Let's plot the predictions
pred <- data.frame(cbind(field.goals$yards,
												 predict(linear,interval = c("confidence"))))
names(pred) <- c("yards","predictions","lo","hi")
plot(predictions ~ yards, data=pred[order(pred$yards),], type = "n",
		 ylim = c(min(pred$lo,0)-0.1,max(pred$hi)+0.1),lwd = 2)
abline(h=seq(from = min(pred$lo,0), to = max(pred$hi)+0.1, by = 0.2),col = "grey40")
points(jitter(good,amount=0.05) ~ yards, data = field.goals,col = "grey40")
lines(predictions ~ yards, data=pred[order(pred$yards),],lty = 1,lwd = 1)
lines(lo ~ yards, data=pred[order(pred$yards),],lty = 5,lwd = 1)
lines(hi ~ yards, data=pred[order(pred$yards),],lty = 5,lwd = 1)

# Let's suppose we want to know what's the probability to score if we kick 
# from the minimum distance
print(coef(linear)[1] + min(field.goals$yards)*coef(linear)[2])
# What does this value mean?

# A linear model can return out-of-bouns predictions. In a linear model, the 
# possible values of Y are unconstrained, while probabilities are only valid
# for values between 0 and 1.

# To be able to model our outcome in the correct way, we need to transform Y
# with a function which makes its values range between 0 and 1 for all the 
# possible values of our predictor(s)
# This necessarily mean that the resulting probability will be non-linear,
# i.e. increments of X will produce bigger or smaller increments of Y
# depending on how close to the bounds Y is

# We can have a practical example plotting the proportion of positive
# outcomes for each value of X

# What does this mean?
# It's equivalent to make a table
field.goals.table <- table(field.goals$good,field.goals$yards)
print(field.goals.table)
# Here we care about the percenteges of 1 respect to the column total
# E.g. for the "18 yards" column, where the only 1 goal is on 1, the 
# proportion will be 1, in the "46 yards" column it will be 
15/(12+15)
# 0.56

round(field.goals.table["1",]/(field.goals.table["1",] + field.goals.table["0",]),digits=2)

# What happens if we plot the proportions of 1 against the values of X?
plot(colnames(field.goals.table),  # The distance in yards on the X
		 (field.goals.table["1",] /    # On the Y the proportion of good outcomes
		 	(field.goals.table["1",]+field.goals.table["0",]) ) # over all outcomes
		 ,xlab="Distance (Yards)", ylab="Proportion of scores", las = 1, pch = 16)
# Here the non-linearity is quite clear

# This helps us seeing the non-linear probability curve, but doesn't really 
# solve our problem
# What is most commonly used in these cases, is called Logistic Regression Model

# R has a nice function for doing it, called GLM, which stands for Generalized 
# Linear Model

# Let's start having a look at the results, then we will enter in the logic 
# of GLM in a more rigorous way
logit <- glm(good ~ yards, data = field.goals,family = binomial(link = "logit"))
summary(logit)
# Let's compare the coefficients with the previous model
coef(linear)
coef(logit)
# what do these coefficients mean?
# If the coefficients of the linear model looked weird
print(coef(linear)[1] + min(field.goals$yards)*coef(linear)[2])
# the coefficients of the logit seem to yield even more absurd predictions
print(coef(logit)[1] + min(field.goals$yards)*coef(logit)[2])

# To get the meaning of these coefficients, we need to understand the logic
# of generalized linear modeling.
# But before...

##############
# Excercise! #
##############
# I want you to re-plot the percentages from the table in a dotchart.
# Use the ?dotchart command to see how it works, or check some old script 
# from this course.
# The result should look very similar to the scatter plot we made, just a 
# bit more fancy.




dotchart(x = (field.goals.table["1",] / 
	(field.goals.table["1",]+field.goals.table["0",])),
				 pch = 16, cex = 0.9, xlab = "Proportion of scores",
				 main = "Field goal attempts and distance")



##################
# Some basic GLM #
##################
# Generalized Linear Models are a class of models thought to extend the linear 
# modeling framework to several types of data generating processes.
# It can be used to fit linear regression models, logistic regression models (used 
# when the dependent variable is dichotomous), poisson regression models (used when
# the dependent variable is a count) and many others.
# Like in linear models, GLMs have a response variable Y and a set of predictors
# X1... Xn. 
# The difference is that GLMs introduce a quantity called "linear predictor".
# In GLMs, the value of our response variable is a function of the linear predictor. 
# While the relationship between the Y and the Xs does not have to be linear, the 
# relation between the Xs and the linear predictor has to be linear.
# The only way in which the Xs influence the Y is through the linear predictor.

#----------------------------------------------------------------------------#
# Let's make an example using the logistic function -- the one most commonly #
# assumed when we do regression with a dichotomous dependent variable.			 #
#----------------------------------------------------------------------------#

# Our response variable is "vegetarianism", i.e. the fact that a person is
# vegetarian. Let's forget for a second about vegans, pescatarians, people who
# only eat chicken and roadkill-vegetarians (a peculiar movement) - in our world
# people are either vegetarian or not.
# Our linear predictor is a latent trait - the sympathy towards animals.
# When it takes value 0, people are indifferent - they don't have either positive
# nor negative feelings towards animals.
# When it takes a positive value, people have positive feelings towards animals,
# and when it takes a negative value, they have a negative feeling.
# People can be extremely positive or extremely negative towards animals, but we
# don't care. We only assume that people with a positive value have a probability
# bigger than a coin flip to become vegetarian, and that people with a negative
# value have a lower probability.
# Our X is the level of empathy, i.e. the emotional capacity to recognize feelings
# that are being experienced by other people. Let's assume it's effect is positive
# and rather strong (beta = 0.8) and that the trait it measured on a continuous
# scale (in last week's version it was a 5-point scale, but I realized that it was
# only more confusing)
#rm(list=ls())
require(MASS)
vcov <- matrix(c(2,0.8,0.8,2), nrow = 2, ncol = 2)
n <- 1000
data <- data.frame(mvrnorm(n, mu = c(0,0), Sigma = vcov))
names(data) <- c("lin.pred","X")

# Our continuous scale comes from an additive index, so it does not have decimals
data$X <- round(data$X,digits = 0)
table(data$X)
hist(data$X)
# We define the probability to be vegetarian as a function of our latent trait
# The function is the logistic function, and it is the same function
# that it is normally applied to obtain predicted probabilities from the 
# coefficients of a logit model. 
# Moreover, it is the inverse of the logit function, i.e. the function that
# the estimator applies to our data to get to the linear predictor (in fact it  
# gives the same results as the "inverse logit" function).
# It is also the function that the GLM estimator uses as a link function between
# your response variable (observed) and the linear predictor (unobserved)
data$prob <- 1/(1 + exp(-data$lin.pred))
# ^ You can find this formula here: http://en.wikipedia.org/wiki/Logistic_function
# If you try with the "inverse logit" you will have the same results:
prob.alt <- exp(data$lin.pred)/(1 + exp(data$lin.pred))
plot(data$prob,prob.alt)
rm(prob.alt)

# So how do they relate?
graphics.off()
plot(y=data$prob,x=data$lin.pred,pch = 20, xlab = "Linear Predictor", ylab = "Probability",
		 las = 1)
abline(h=0.5,col="red")
abline(v=0,col="red")

# Now, the next step would be to assign each variable who has probability bigger 
# than 0.5 a response of 1 and each variable who has it lower than 0.5 a response
# of 0.
# But we like it random, so we will simulate it with rbinom()
data$response <- rbinom(n = n,size = 1, prob=data$prob)

table(data$response)
# This is everything we can observe about the data generating process
# This is equivalent to the number of field goals attempted in our American football
# data set.
plot(y=jitter(data$response,amount = 0.05),x=jitter(data$X,amount = 0.1), 
		 pch= 20, xlab = "Empathy scale", ylab = "Response",
		 las = 1)
# vs.
plot(y=jitter(field.goals$good,amount=0.05),x=field.goals$yards,pch=20,
		 las =1,xlab = "Distance (Yards)", ylab = "Outcome")

# The difference is that this time we completely simulated the process that
# generated our data.
# while in the "field.goals" data set we only have the "outcome" variable (the 
# outcome of goal attempts), here we also have the "linear predictor", that was used 
# to generate the "probability", that was used in turn to generate the "outcome".

# Let us see how the response relates to the probability
plot(y=jitter(data$response,amount = 0.05),x=data$prob, pch= 20, xlab = "Probability", ylab = "Response",
		 las = 1)
abline(v=0.5)

# Let us see how the response relates to the linear predictor
plot(y=jitter(data$response,amount = 0.05),x=data$lin.pred, pch= 20, xlab = "Linear Predictor", ylab = "Response",
		 las = 1)
abline(v=0)

# Notice that the linear predictor does not have a substantive meaning - like, in
# our case, "sympathy towards animals". The linear predictor is a necessary latent
# quantity estimated in Generalized Linear Modeling to allow us to model our 
# dependent variable as a function of our independent variable(s).
#
# We never have information about the linear predictor, but we only have
# the "response" variable, i.e. our set of 0s and 1s.
# Therefore, we need to tell R (or whatever other software) how is our dependent
# variable distributed and how the distribution is linked to our linear predictor.
# Then R will estimate the effect of our independent variable(s) on the linear
# predictor only.
# The information about the distribution of our dependent variable is defined in the
# GLM command with "family", and the function that links it with the linear predictor
# is specified via the sub-option "link".
#
# In our simulated data, we know the family (what kind of distribution was used to 
# generate our dependent variable?) and we know the link function - indeed we have 
# used it ourselves to generate the probabilities.

# In other words, the logistic regression does the inverse process of what we have
# done so far

logit.1 <- glm(data$response ~ data$X, family = binomial(link = "logit"))
# ^ notice the "family" and "link" specifications.
summary(logit.1)

# To have an idea of the meaning of the coefficients of a logit model, let's compare 
# them with the coefficients of a linear model predicting directly the linear predictor
# (impossible in the reality)
linear.1 <- lm(data$lin.pred ~ data$X)
summary(linear.1)
# (by the way, this can be done with the glm() function as well, and it will return
# the same result)
linear.2 <- glm(data$lin.pred ~ data$X, family = gaussian(link = "identity"))
coef(linear.1)
coef(linear.2)


# However, let's compare the coefficients of a our logit model of the dichotomous
# dependent variable and the linear model of the linear predictor:
coef(linear.1)
coef(logit.1)

############
# Exercise #
############
# Before we generated our response variable from the probabilities by running a
# rbinom() function, i.e. adding some randomness to our data generation.
# Let's try now to create a new response variable, called "response.new", by 
# assigning an outcome equals to 1 for every case where the probability is 
# bigger (or equal) than 0.5 and to 0 when the probability is smaller than 0.5.
# Then, run a logistic regression on this newly-created variable, and compare
# the coefficients with the ones in "logit.1" and the ones in "linear.1"
# Which coefficients (the ones in "logit.1" or the one in the model with the
# new dependent variable) get closer to the coefficient of our imaginary linear
# model on the linear predictor?





data$response.new[data$prob >= 0.5] <- 1
data$response.new[data$prob < 0.5] <- 0
table(data$response,data$response.new)
logit.2 <- glm(data$response.new ~ data$X, family = binomial(link = "logit"))
summary(logit.2)
coef(linear.1)
coef(logit.1)
coef(logit.2)



#######################################################
# How to get meaningful quantities from a logit model #
#######################################################

# We have an interpretation problem here: since the linear predictor is an abstract
# quantity, we can't really tell what is the substantive effect of our independent
# variable(s) on our response variable.
# However, following the logic of what we did above, we can obtain predicted 
# probabilities from the coefficients of a logit model.

# We know how to do it: we need to use the same formula we used before to transform
# the levels of the linear predictor into a set of probabilities
# Two types of function will produce probabilities out of the model coefficients:
# the logistic function and the inverse logit function.
# Let's compare them
a <- c(-5:5)
# logistic function:
1/(1 + exp(-a))
# inverse logit function
exp(a)/(1 + exp(a))
# The latter is more comfortably calculated automatically by the inv.logit() 
# command in the "boot" package:
require(boot)
inv.logit(a)

# So, let's have a look at the probability to be vegetarian for those who score 
# -4, 0  and 4 (minimum, middle value and maximum) in our X scale
inv.logit(coef(logit.1)[1] + -4*coef(logit.1)[2])
inv.logit(coef(logit.1)[1] + 0*coef(logit.1)[2])
inv.logit(coef(logit.1)[1] + 5*coef(logit.1)[2])

# A good way to present the results is to make a plot - as we know.
# Of course, while with the linear regression we have the abline() command to 
# save us, here we will need to work a bit more on it - nothing particularly
# difficult.
# To extract some quantities of interest, we first want to make a sequence
# out of our X variable
X.seq <- seq(from = min(data$X), to = max(data$X), length.out = 100)
# ^ better to have a high number of points
# In theory, we can create a sequence of completely arbitrary points. However,
# we want our predictions to be meaningful, i.e. to return the probability that
# the event we are interested in occurs for some credible values of X


# The second step is, for each of the points in our sequence, to derive predicted
# probabilities given the model coefficients
p.prob <- inv.logit(coef(logit.1)[1] + X.seq*coef(logit.1)[2])
# ^ this will create a vector of predicted probabilities
summary(p.prob)

# Then we can plot it
plot(p.prob ~ X.seq, type = "n", las = 1, xlab = "Empathy scale", ylim = c(0,1), 
		 ylab = "Predicted probability", main = "Probability to be a vegetarian")
abline(h = seq(from = 0,to = 1, by = 0.1),col = "grey90")
lines(p.prob ~ X.seq)

# If we want to be fancy, we can add the proportions of positive response for 
# each category of X
vegan.table <- table(data$response,data$X)
print(vegan.table)
points(colnames(vegan.table),  
			 (vegan.table["1",] /    
			 	(vegan.table["1",]+vegan.table["0",]) ), pch = 20) 
# However this won't work all the time, for example in some cases we may not have
# so well-defined intervals in our X variable

# Let's see how it works with our field goals data (which have been made up even
# better for this purpose, by the way)
logit.field <- glm(good ~ yards, data = field.goals,family = binomial(link = "logit"))
summary(logit.field)
X.seq <- seq(from = min(field.goals$yards), to = max(field.goals$yards), length.out = 100)
p.prob <- inv.logit(coef(logit.field)[1] + X.seq*coef(logit.field)[2])

plot(p.prob ~ X.seq, type = "n", las = 1, xlab = "Distance in yards", 
		 ylab = "Predicted probability", main = "Field goals", ylim = c(0,1))
abline(h = seq(from = 0,to = 1, by = 0.1),col = "grey90")
lines(p.prob ~ X.seq)
# Let's add the points of the proportion of field goals for each distance
points(colnames(field.goals.table),  
		 (field.goals.table["1",] /    
		 	(field.goals.table["1",]+field.goals.table["0",]) ), pch = 20) 



###############################################
# How to put a confidence interval around it? #
###############################################
# The last step of our result-visualization is to show the fitted line of predicted
# probability with a confidence interval around it - so our teachers and our readers
# will be happy and you will get an A+ in your term paper

# However, this may be a bit more complicated business - nothing too difficult for
# us, but it will require simulation.

# What do we have to simulate, exactly?

# The idea is that, in order to create a confidence interval, we need to get a 
# distribution around our predictions. This distribution will take into account
# the standard errors of our estimates.

# How to do it? We can use our beloved mvrnorm() command
coef.mat <- data.frame(mvrnorm(1000,mu = coef(logit.field), Sigma = vcov(logit.field)))
names(coef.mat) <- c("Intercept","yards")
View(coef.mat)

# Do the simulated quantities correspond to our coefficients and their uncertainty?
# Let's figure it out:
hist(coef.mat$Intercept,col ="red", freq = F, las = 1)
# The mean should be where the value of the coefficient is returned
abline(v = coef(logit.field)[1], lwd = 2)
# The confidence interval keeps the 95% of the observations, and it goes from
# -1.96 to +1.96 standard deviations from the mean. 
# As you know, the standard deviations are the standard errors, and we can get
# them from the diagonal of the variance-covariance matrix
abline(v = coef(logit.field)[1] - 1.96*sqrt(diag(vcov(logit.field))[1]), lwd = 2)
abline(v = coef(logit.field)[1] + 1.96*sqrt(diag(vcov(logit.field))[1]), lwd = 2)
# Let's check it for the coefficient of "yards"
hist(coef.mat$yards,col ="blue", freq = F, las = 1)
abline(v = coef(logit.field)[2], lwd = 2)
abline(v = coef(logit.field)[2] - 1.96*sqrt(diag(vcov(logit.field))[2]), lwd = 2)
abline(v = coef(logit.field)[2] + 1.96*sqrt(diag(vcov(logit.field))[2]), lwd = 2)

# Now that we decided that we trust our simulated sets of coefficients, we need
# to make a sequence of values of X, as we did before

X.seq <- seq(from = min(field.goals$yards), to = max(field.goals$yards), length.out = 100)

# To plot the predictions with the confidence interval, for each point of this
# sequence (that we will put on the x-axis as we already did), we need 3 quantities.
# 1. The point estimation, which should be the mean of the simulated distribution
# 2. The lower confidence bound
# 3. The upper confidence bound
# To obtain these quantities, we need to loop around the values of our sequence. 
# Each value will be "plugged in" in our set of coefficients, creating a distribution
# of probabilities, rather than a single one

# First, we want to create an empty data frame where to put our simulated 
# probabilities.
sim <- data.frame(NULL)

# Let's start the loop
for (i in 1:length(X.seq)){
	# Generate a distribution of probabilities for the value "i" in the sequence
	probs <- inv.logit(coef.mat$Intercept + X.seq[i]*coef.mat$yards)
	# Save the mean
	mean <- mean(probs)
	# Save the lower confidence bound (0.025% of the distribution)
	lo <- quantile(probs,prob = 0.025)
	# Save the upper confidence bound (0.975% of the distribution)
	hi <- quantile(probs,prob = 0.975)
	# Update our data frame, keeping track of the level of X 
	sim <- rbind(sim,c(X.seq[i],mean,lo,hi))
	print(i)
}
names(sim) <- c("yards","prob","lo","hi")

plot(sim$prob ~ sim$yards, ylim = c(0,1), las = 1, ylab = "Predicted probability",
		 xlab = "Distance in yards", type = "n", main = "Field goals")
abline(h=seq(from = 0, to = 1, by = 0.1), col = "grey90")
# First we plot the point estimation (it will be the same as the line we
# have drawn before)
lines(sim$prob ~ sim$yards)
# Then, let's add the lower and the upper bound
lines(sim$lo ~ sim$yards, lty = 3)
lines(sim$hi ~ sim$yards, lty = 3)
# If we want to be really fancy, we can add the points
points(colnames(field.goals.table),  
			 (field.goals.table["1",] /    
			 	(field.goals.table["1",]+field.goals.table["0",]) ), pch = 20) 
# Nice & fast

############
# Exercise # 
############
# Try to replicate the simulation with our model about vegetarianism, "logit.1"
logit.1 <- glm(data$response ~ data$X, family = binomial(link = "logit"))
coef(logit.1)
vcov(logit.1)
# Then plot the predicted probabilities with a confidence interval around.

for (i in c(2,5,7)){
	print(i)
}

i <- 1
while (i <= 100) {
	print(X.seq[i])
	i <- i + 1
}
i
a <- 1:10
logit.1[1:20]